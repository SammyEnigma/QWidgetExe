(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('北屯市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"659005","properties":{"name":"北屯市","cp":[87.824932,47.353177],"childNum":2},"geometry":{"type":"MultiPolygon","coordinates":[["@@ ^ZF@@B@B@BAB@D@DCDADAB@B@@@@CBAEAA@CAA@C@A@C@A@CAA@AAA@AACAAAE@C@CA@CAAA@C@C@AACAAADACCC@ABC@A@C@A@C@AAC@ABC@AACBCAAA@AAACAA@KJGL"],["@@ƈ@´@@A@A@EAA@ABAF@HAB@@hMHEAEAEBGDCHKHLLBBLGJED@FDJ@PB@CBABAD@D@BDBDDBD@DABA@C@EBCDAF@D@DADAFGJGB@F@BBFBD@BA@C@CEE@A@@BAH@D@DBDFBBD@DAF@BBBB@BBDBDD@F@DAJEFCD@ACGE@@BABAHCDCJ@CGAAA@EBEBEB@CMAI@ODGBGDQB@]BAB@BAB@B@BA@@B@BABADABA@A@@B@@ABA@@@@BABA@@@@@@JCNELEB@@@B@B@RJB@DB@@@@@@A@B@@@@BB@@@@BHBBBB@B@B@@@BBB@@B@F@D@B@B@B@B@BB@HBDBL@FBDAD@FANC^GB@@@B@@ABABAB@VEB@D@VEXEDAD@PG@AD@`@ZAJCFAD@B@V@B@BAJCBAXMRIFCDADAFA^IBAB@HGB@BAB@BANAJCNAZGUFALENAPCPCDArOJ@`EfETDRD`DHDJTFDH@RWRITCtBdBfL\\BPHPLBCBEAC@C@GAKAEAEa@qA}@C@G@E@I@CMDIFOAS@OIOBOFECEaqWEAEGAIACGA¡GSAKCaIQIQCEDEBIBAB@@DB@BGA@AAAE@EBEBCCACC@C@E@C@ECE@EDADBBFBF@@DKDEBK@CDEDMBKCCCKEK@WHEB@FBF@HCFGDSDODKBKAKAC@A@ECCAE@GDMBK@I@GBGFGBIACDGDG@ABC@AB@BMBE@CBE@S@CBEBI@CBEHEBGBK@GFEDK@IGIGEAAFGAGEEAMBSFCBCDMHQDKDKBK@YDO@EDIDSBIHOTIDKAMBGFG@EFIBCAGAMHQNAFIFIFADBD@FGJ[PIJGJQJSPEBYAMDYTWJcDWJgX¡nXHHDF"]],"encodeOffsets":[[[89581,48550]],[[89658,48494]]]}}],"UTF8Encoding":true});
}));