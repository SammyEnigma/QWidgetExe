(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('琼海市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469002","properties":{"name":"琼海市","cp":[110.466785,19.246011],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@_OeUYY[MMEOEKAGIUocGcQÉ­FUBKFCH@LAB@@C@@@ABA@A@@AA@CAAAC@A@C@ADA@@BMOEGIQKEE@GFEHKLOJQ@OKDODQKOOKKAU@QGMGOGKGOK[KYESGIAMAACC@@A@A@A@ABAAGBGA@@AAA@A@@A@A@@@A@@@@A@ACAA@EAA@C@C@E@AAAACAA@A@C@AAC@A@CF@BA@A@A@AC@@A@C@@@A@@A@ACGIIECMEGCE@CDC@QAIEICYE@BA@A@@@CBADAFEFCDAD@BAB@BAB@BAB@BADABABCB@BA@@@AAAAAACAAAA@GB@@EA@@A@ABA@A@A@AAECA@A@A@A@ABABABAB@DBD@DBBBF@B@BABC@C@CBCAA@AAAA@I@E@CDEBABA@CACA@CAE@C@EBCBABAFCJCDEBCBCDAFA@CCIQAB@B@BAB@B@BABCBAD@BBDBF@DB@BBBB@@@BABABABABC@E@CBCBIN@DADCBEBEDCDAF@BGBAFCJAJFF@J@@BFBPAJAJCRAPBNERCRAHD@DDHHDDFHJLLT@P@NHN@FCHALDPHLJ@JKPONGRFVJZHJDHDNDN@F@CNALJ@NBJDLCJEPKL@JBJHJDJALEDANBRRNJRBJEFEFCJBHHDPCJGJCJ@LBLBJHLDDNBLBFJ@JALCLEFUHSJGFGDCNFJFJDP@DFXLJL@NALBFFBL@DCL@PLTHDHDP@JBHBNLBHJPHFHAFCPCHFFJDLBHHJHJFDLJLBN@VIL@JAHDFFBJBHJNLJJBRCTEPDVDHcFITCJCLMDGHKDK@QEQBGLGDKAQAIAMBKHKPGPCRHHFJFNJAHAPBJFPDDJANGDHBHJDLBPCPEFA¬Y"],"encodeOffsets":[[113388,19844]]}}],"UTF8Encoding":true});
}));