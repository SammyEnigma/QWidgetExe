(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('文昌市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469005","properties":{"name":"文昌市","cp":[110.753975,19.612986],"childNum":12},"geometry":{"type":"MultiPolygon","coordinates":[["@@@BFFFBBBAHBDLBDB@DABC@EAC@E@AB@@BDA@CAAAA@AF@DDBDABBDBBDBBBDDDDDD@BDDDBBBBBDD@FBFABDBDBBBADA@AACFG@CFCFAD@@@@@D@HBB@@@@@B@F@@@@@@@BBFDJDDBBB@BBBAB@DCFAH@HAJADCD@@@DDHHDDBDDHDBDAHIDABGHAFCDI@C@E@EAEAEAGBA@ELAFBFFFFDBF@DADAL@DAFEDCD@BBD@B@BBDBFADABADABA@AB@DABAB@BA@@BA@ABAFA@C@CDGFABAAA@A@E@C@A@A@BB@D@DDD@DALCD@DCFAFCBC@ABABAD@D@D@D@BADC@EB@@@B@B@BA@@@G@@@A@A@CB@BEBEDGBIBCDCBCBA@@B@BBBBB@D@F@F@B@DABADABEJEDIHEBGDEF@@AHCFGHEB fjRPPLTFRLXJLDRRFHNLTRFDB@B@D@F@HAPELGHGDE`³N_FCDArETELGPKRWPUZSlQbGXCPVL\\H\\ANGJKFOhÉtý~ñrģFmEUMMWIQC]AS@O@SEUMm{gg{qii{KGQGOEuEEAIM«ZEBOFODKAICAGCGMHIBCCEOAIBOBGMIIEGEQGODOHGLALBNBJBRCLKHAHFR@RCLGLCHKNIDSDEJGdHHBFBNAJEHIJGFSLQLMBK@KCQEOGE@G@GDCDCJ@LCRBLDDFFLFNJDFDHJHLDNDF@B@FDBBDBBABADADABCB@BFBBDBDAD@F@J@FBD@B@BB@AAC@@AC@GAEAEAACICCBEAC@@F@DBF@D@FCDCBGDCFAD@FCH@FDH@DBJBRBFBD@BCBAB@B@DBFADBDAD@@FDDFBF@FCHDBBF@@BF@DJB@BBB@B@@DBFBHAF@BBD@@@DABA@AAC@@DBDBBBDCDCD@BAD@D@FBF@D@H@F@D@FBDDBDD@BB@BD@DBBFDBBDFBHBDDBBB@BBD@B@DABADBB@BBB@D@B@@ABABBBBBD@@DAB@BD@HBFDBBDBD@BDB@BB@BC@E@G@C@CACBADCDC@A@IBC@C@CA@@CBCBEACDCD@@ABCBABCDAD@@@B@@@BB@@B@F@HAJCH@DBBBDD@@B@D@FADABA@GCI@EBCBBDDDDDDAD@DB@@B@D@BBBBBBBBB@D@DAD@D@LDHA@@@BBBBB@JCFIBKFGBCBAJCFCFAFDFBFBHBBFDDBDDBJBFFJBH"],["@@@B@@@BB@@BA@@B@@@BB@B@@@B@BBB@@A@@@A@@AABA@A@@BABC@A@A@AA@@@ABA@@BA@@@ABABA@@B"],["@@@B@@BB@@@@B@@@@@@@B@@@BB@@B@@@@A@@AA@A@@@@A@@AA@@@A@A@@B"],["@@@@@BB@@@@A@@@@@@@@@@A@@@@@"],["@@@@@@@@@@B@@@A@@@@@@@"],["@@@@BB@@B@@B@@BB@@B@BB@@B@@@@@@A@@@@@A@@AA@A@@A@AA@@A@@@A@A@@B@@"],["@@@B@B@@@B@@B@@@@@@@@@@A@@@@@@@@@A@@AA@@"],["@@@@@@@@@@@BB@@@@AA@@@"],["@@@@@@@@@B@@@@@@B@@@@A@@@@A@@@@@"],["@@@B@@B@@@@@@@@B@@B@@@BA@@A@@@A@@A@@A@@@"],["@@@@B@@B@@@@@@@@B@@@@A@@A@@@@@@@@@A@"],["@@@B@@@@@B@@BB@@@B@@@@B@@@@@@@B@@@@@@@B@@A@@@@@@@AB@@A@@@@BABA@@@AB@@A@@@@@A@@@A@AA@@@AAA@@BA@@@@BA@@@A@@B@@@B@@@BCB@B@@"]],"encodeOffsets":[[[113296,20243]],[[113943,20459]],[[113936,20444]],[[113935,20443]],[[113930,20442]],[[113924,20438]],[[113872,20402]],[[113873,20404]],[[113875,20391]],[[113886,20359]],[[113885,20360]],[[113871,20387]]]}}],"UTF8Encoding":true});
}));