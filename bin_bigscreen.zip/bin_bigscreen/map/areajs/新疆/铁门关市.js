(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('铁门关市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"659006","properties":{"name":"铁门关市","cp":[85.501218,41.827251],"childNum":3},"geometry":{"type":"MultiPolygon","coordinates":[["@@HNZGfMMKyT"],["@@BA@@@@@A@@@@BA@@BA@@B@@AB@B@FAB@B@@A@@B@@@@@@@B@@A@@@@@@@A@@B@@@BA@@@@B@@AB@@A@AB@@@@@B@@@BA@@@@@A@@@@@@@@@A@@BA@@@@@@@AB@@AB@@A@@@ABA@AB@@@@@B@B@@@BA@@BA@@@@@A@@B@@@@AB@@@@@BA@A@@@A@C@@@C@A@A@A@A@@BA@A@A@C@A@EBC@A@C@A@ABA@@BA@@@A@@A@@@@AA@@A@@@A@@AA@@B@@@@ABAB@@@@A@@@@@A@@@A@A@@BA@@B@BABAB@@@@@BA@A@@@@B@@@B@@@B@@AB@@@B@B@B@@@B@@A@@A@AA@@A@@@@@@A@@@@BA@@@AAA@@@@A@AAA@@AA@@AB@@@@A@@@AB@@A@@@@BAB@@@@@@@@A@@C@@A@@@@@@@AB@@@@@@A@@@@D@@@@A@@@@A@@@@@A@AA@@@A@@W@E@EArmCD¾CýC§C^£CëITâ¶fÖlJLFfBNJbNCTC`GnIOHAFARGdKHCPCbGXEVETC\\GTEXERCFANAR@XUjSHCDC@E@SKCAGQACC@IEAG@CACCAI@KAGGMcaAA@EDA"],["@@GUAEEUAEQ@]BA@[@@`uAAewGEBKLEDO@A@ABAJEDGBMBIAK@GAEC@CDCJCN@P@@GY@O@GASCA@ACBAF@Z@BABCCAICYAEBAF@JFFHDLF@B@DABE@GCCCMMMGO@[AEBCDB\\SAEDBX@RX@LnHDd@VEVIREVAZBTAnGNAN@XELAV@`BdDXCPGFC"]],"encodeOffsets":[[[87459,42949]],[[87800,42758]],[[88167,42802]]]}}],"UTF8Encoding":true});
}));