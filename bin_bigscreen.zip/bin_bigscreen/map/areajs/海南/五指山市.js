(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('五指山市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469001","properties":{"name":"五指山市","cp":[109.516662,18.776921],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@@A@ABCBGBEDEFABA@A@@@@AACA@AAA@C@C@A@G@A@ABADCDA@ABC@A@CBAB@BABABCDCFE@ABADMBE@C@O@A@CDEFKDC@@HAPEDAB@DAB@BA@E@CBCBGDABCDAF@H@F@B@B@B@F@BA@@@ABEDEBC@EBA@@B@B@@@BBB@JDFAJ@B@BB@BB@@F@DB@@BJBF@@@HCDADCB@BABB@@B@@B@BB@@@BBN@@@BAB@D@DADAB@B@B@B@B@BB@BBB@@D@@BB@B@BB@@B@@BB@@@@@B@@BB@@BBDB@@BB@@AB@@AB@D@B@@@B@BBDBBBB@BAD@DADADCBAB@@ABBFBB@@BD@@@DADABADE@AD@DA^C@@BA@A@A@ACEECGGCACAA@EBC@C@CACAEGGECCAE@A@ABE@AHIBAFADCDCFEBABCBG@C@CAG@CAI@C@E@A@C@C@@BC@@@AA@KCE@I@A@E@A@C@A@C@@@CAAA@AAA@A@@AA@@AA@A@@BEDGFCDC@@@A@C@A@@AAA@@AA@AAA@AAAAAE@A@ABEDG@@AAAAGEAA@@BAB@BABA@ABABA@A@A@AACBCHG@ABA@E@ABAFGBADKFK@CBABCBCDG@A@A@@AAAA@E@EAC@AA@AAABCBC@A@A@AAE@E@EBCBCDA@EBC@A@A@AA@@EAA@C@CAA@CACBE@CBA@CACAA@AAA@ABA@@@A@@@C@@@A@@A@@BA@A@A@AAA@ACC@A@EAAA@CCAA@A@A@CBCBA@A@A@@CGAGAA@@A@@BA@EB@@A@AA@ACGCCAC@A@C@@A@ABEDEDCDAB@FABCBABA@ADA@A@A@@@AAA@EBA@A@AFCHABABABA@ABA@@B@FAHABA@CBCBA@E@A@C@AB@BABBFBBBBFBD@B@B@D@B@B@@DBFBJ@F@BAB@@A@CBEBCBCAEA@@A@CBCBA@C@A@@@@@@A@@@@B@B@@@@@@A@A@@@ACCCACAIACCAA@A@E@AA@ECAAAAAE@EAAACAAAACAGACAAAGC@A@A@C@CDABA@CDIBKDG@AAA@@CA@AAC@C@ABABABABCDGDA@C@@@ACAC@KAC@@AAC@CAACCA@C@C@CBABC@CBABA@AB@@A@CAGACAMEEAC@C@E@C@AB@@C@E@CAC@ABAB@BA@E@C@AB@BABA@A@E@A@A@CBEBABA@CCEEAC@@AEAGEKCCCCEECAAAC@E@C@G@A@E@AACBA@C@@@@B@@AB@@@BAFABA@A@ABEFCDADAD@BBLBHDL@F@HAHEHED@@E@G@ABAB@B@DCHEFEFONIFKRAF@LAPBHDDBD@DAFCFAFCP@BBBBBD@@DABABCFAF@LBFDBHA@@B@BBA@@BCB@B@D@FAD@FAHAH@BBD@B@B@BABABAB@B@F@D@B@BBBDBBDBBBH@BBDDB@@@D@D@F@B@@AB@BBB@@@F@B@@DB@@BB@B@B@BB@BBDBDDDBBDBB@B@BABADEFCFCDEHCFEBABA@A@A@C@ABEBC@A@CB@@@@@B@@BBBB@@@@B@@@B@@B@@@@@B@@@@@@@@@BA@@@@@A@@@A@A@@@@@@@@B@@@@@@B@@@B@BB@@BB@@@@@B@@@B@BA@@BA@@BA@@BAB@@@@@@A@@@@B@B@@@@@B@@@BB@@B@@@B@@@@AB@@AB@B@@A@@B@@AB@@AB@@@@@B@@AB@@@B@@@B@@AB@BA@@B@@@@AB@@@@ABA@@@A@@AA@@@AB@@@@A@A@@@@@@@EH@B@@@@D@BB@@@B@BCD@DBBBDBBJDFDBBBD@F@BBB@BBBD@B@D@B@BB@@B@@B@DLCJAB@DCBCBCBABAB@B@DBDBFBFDFD@@@D@B@B@D@@@BBBB@DBB@BBB@@BBBB@@@BBB@@@B@B@B@B@B@BBHFHFBBB@BBB@@@@@@BABAD@@@BB@@BDDDD@BBDDDB@BB@@DBBBB@BB@BBDBDBB@DB@BBB@B@B@B@DAD@D@B@FBF@BBFBBBB@B@B@D@@@DBD@DBBBBDBD@DBHBFBPFR@HBBBB@@BADABCBAB@BAB@F@FBFBHDDBD@B@BADADAB@DAH@B@BBDDB@@@B@DAD@DAD@HD"],"encodeOffsets":[[112153,19488]]}}],"UTF8Encoding":true});
}));