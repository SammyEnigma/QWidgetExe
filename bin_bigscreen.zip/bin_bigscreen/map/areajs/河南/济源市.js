(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('济源市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"419001","properties":{"name":"济源市","cp":[112.590047,35.090378],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@DFJFFFDFJDD@BABACK@C@CDI@AB@B@DNDJDBBBDAHABCDI@K@CBAB@@@B@D@B@@ABABAHAJEDET@BE@GXQFAR@BC@AIIAOLWBEF@FTJTLFHBJ@B@HCBADADAFAHAB@BB@@B@@@H@AC@E@CBADADCDCBCBCBIACCO@E@@@@CQ@G@ADA@C@EAK@I@AB@BABAAGAKBIBIBI@EAEEEECKEAA@E@Q@AGIACAICKCEGECACA@C@GAUOQIEKAICKEMEUMACCCACEKEOCEKGGCC@G@@@@@ABGBA@CAAC@ECCIEE@G@[AGBIBC@A@CCEE@@@@CCKAGAG@OBE@C@CCEIKMAC@@@@AA@@@@@A@@EG@AAACAEAAAA@@CAEAA@@EACAK@@@@@EACCCACACCC@EBCDEFCDCBCBCAEAAAA@CBCD@@A@@@GKCQCAAE@AJBJABAD@B@B@DHFJHBL@DAHQD@FCBCEG@CBCBCA@CBIHC@CA@@DEHEHCAG@A@AFAACA@C@C@AAC@C@C@A@C@A@CBABCBABA@EBCBC@A@CACACAC@A@A@CBABCFADGDMHWJIDQFQBWDU@GAMCQ@W@CBCFCDOFOFI@IBKHOFKDKDMAM@UDQFOJMLIHC@E@GCEEECIKGKICKBIF_Z]RUFQBIHEJM\\QVGJOJEDEBGBSDMDKBGDOFGDCBABAAEBCAAACBIBE@GBEAA@EAE@G@K@MAC@GDCBC@C@CACCC@EBEDADABDFDF@D@F@@@BHBF@DCDAD@DBRXBHAF@J@HBH@FMVAHBJFPH^H`@B@BI@ABAD@BBBJJ@DBDADELUdKLINAH@HDFLHHBNBHHJHVJFD@FADAD@FBPAHMZCNEFOHGDA@@B@BBBDDBD@DPCRAJBJBDBF@HALCJCLAD@B@BA@@B@@@@@@A@@@@@AA@@@AA@@A@A@@@@@A@@@@@@@@A@@@@@A@@B@@@BA@@@@@AB@@@@A@@B@@@B@@@B@@@@A@@@@B@@@@@@@@B@@B@B@JDFBNFB@F@NCZENARARGRGTC\\@FAHMACCCAAACB@DALAXCLAFBHDXFbBJ@FDBBPPDBJ@DABACKUgCECEBEB@J@LDNDH@JAJAF@HDF@JCL@R@HBJBRAHBJFRPLNJFL@JALCL@LALCVETGNEDBFDDDH@HALEJCBABBFFBBBBB@JEHAFAVMD@DBDBRDRBB@F@HEJEPGDAHAF@D@BB@F@FBBFBDBJ@H@PBXBF@FCNAF@D@LDPFFBBBBBAFCNABABKBI@IDAD@DAJ"],"encodeOffsets":[[115320,36098]]}}],"UTF8Encoding":true});
}));