(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('五家渠市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"659004","properties":{"name":"五家渠市","cp":[87.526884,44.167401],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@@@@@@@@BB@@@@@@B@@@@@B@@@@@B@@@@@@BB@@@@@B@@@@@@@@@B@@@@@B@@B@@@@B@@@D@@@@@@BB@@@@@B@@@@@B@@@@@@@B@@@@B@@B@@@@@B@@@@@@@B@@@@@@@B@@@@@@B@@@@B@@@@@@@@@B@@@@@@@B@@@@@@@@@@@B@@@@@@@@AB@@@@BD@BADGFQNEFDBJJHNBBDFHH@DAB@DAFDDJLJJ@@BD@@IFQRBB@B@DCBA@BB@@@BBBBBB@B@@B@B@@@HB@BB@B@B@BC@A@@@BBBB@BABE@@B@B@@ABBB@@B@BA@A@@BA@@BB@@BBB@@@B@B@BB@@BBB@ABAB@@@@C@@@@BA@BB@@@@BBBB@BB@BB@@@BA@A@A@A@@B@@BBBB@B@BB@BB@@@@B@B@@BBF@BBDADAF@B@@CJB@BB@B@@@B@@A@A@@B@@BB@@DABB@BA@AB@@@B@A@@B@B@@B@BA@@@@@@BB@A@AB@@A@AB@@BB@@B@@BAB@B@BC@@@A@AB@D@BB@ABAD@BABD@@B@D@@ABA@A@CFAB@@ABAB@@@@EFCD@@@@GHA@@BA@WVIDKDEB@BDF@B@B@@AB@B@@@@B@DABBBB@BBD@@A@AAA@A@@DBB@@@AD@BB@@ABCB@BDBH@D@@@BBDBD@BBGJQLMLWRm^GD@BC@CB@@A@@@@BBD@BC@A@A@@BBB@BA@@BDDFF@B@BAAA@AB@DDBFDBBB@ABA@AB@DBHBDAD@B@B@B@F@F@F@F@D@DABAF@FBHHFHDF@HF@F@JADBDHF@FCHBFDFCFAFCHCJAPCDGDGHAD@DBBDB@A@ADADDBDE@EDCBBBDABB@DABG@G@CB@DFB@HBBDDADEBEACCCDCDCFFDDDABC@CAAB@D@BCFFDBBABCD@BABC@EFAFBDBD@HBFABEBEDABCAC@AD@DC@E@GBCBADIBMBEDEFBDBB@B@DBDBBPAbCERAN@B@FDF@DCBAJ@DA@C@G@G@AH@L@Z@t@L@B@@DGNCJGLABAFCBBDHDBBABAFADAJAHBFSFA`GFABGX_NWR]BAHB@@@C@@@AA@BA@AB@FI@A@@@@@AAA@A@A@@@CBA@AB@@CBABC@ADEBC@ABAAA@@AC@C@AAC@AAAACAAAA@A@@AA@A@@BC@@@ABA@@AAB@@@@@BA@ADA@AB@D@B@B@BAB@D@DAJAHCJAHEHEFCDEBCBEBCPCLA@A@@@@@A@@@AB@@@@@@@@A@@@@@@BABC@A@@BA@AA@@A@@@@@A@@@@BA@@@A@C@@BA@A@CBC@A@ADCBC@ABC@ABA@A@@@@@@@@~A@EAO@HCDA@@@@D@FCBADABAFC@@DABAFC@@@E@GA_@UCyAc@]@A@@A@CCQMSOBKBIMGA@@@@@@@@@@@@AB@@@@AB@@@@A@@@@B@@A@@@@@@@A@@B@@@@@@A@@@@@@B@@A@@@@@@@@@A@@B@@@@@@A@@@@@@gYAAcYIBAB@@@@A@@BAB@@@B@@@@@B@@A@@@CB@@AB@@C@AB@@A@@BA@@@@D@B@B@B@B@DBD@B@DBB@D@B@B@@@@BBBB@@@B@@EBKDE@A@IDE@AB@@KBA@CBE@A@A@A@GB@@@B@@B@@B@@B@@BBB@B@@@BA@@BA@@B@@A@@@@B@@@@@@@B@@A@@B@@@@@B@@A@@@@@@B@B@@A@@@@@A@@B@AA@@AAA@@A@AAAA@@AA@@@@@@AA@@A@@AA@AAA@@AA@@@@@@AA@@A@@@@@A@@@A@@A@@@@@@@@A@ABA@@@A@A@A@A@@@A@@@A@A@@@A@AAA@A@A@AAAB@@A@A@A@@@A@@@C@A@@@A@@@@@A@@@@BA@ABA@A@@@@@@@@@AA@@@@@AA@@@A@@@@@A@@@@@A@@@@AA@@@@@@A@@A@@@AA@@@@A@@@@@A@@@@@A@@@@@A@@@@@AA@@@@@@A@@A@@A@@@AA@@AAA@@@A@@AA@@@@@A@@@@@A@@@@@AA@@A@@AA@@@@@@@@@@@@@@A@A@CB@@@AAA@A@AAA@@@AAC@@@A@AAA@A@@@A@A@A@@@A@A@AB@D@B@@@@@@@@AB@@@BA@@@@@@@A@@@@A@@AA@@@@@A@@@@A@@@A@AAA@A@@@C@C@A@@@@@AAC@EAA@A@CAA@@@@@A@C@C@E@A@@@@DA@ADAFEBBHECABG@AB@@AB@B@@@@AA@@A@A@C@C@@@E@A@A@@@@@A@@@A@A@@A@@@A@@B@@@@A@@@@B@@@@@B@@@@A@@@@@@@AB@@@@@@@@@B@BB@@B@@@@A@A@@@A@A@@@@@ABA@A@@AA@@@@A@@@@A@@@@@@@@A@@@@B@@@B@B@@@@@@@@@A@@@@@A@@@@A@@@@@@@A@@@@@@@@B@@@@A@@@AA@B@@A@@A@@@A@AAA@@@@@@A@A@A@@A@@AA@A@A@C@A@A@AB@@@@AA@@@@A@@@A@A@A@A@@@A@@@A@@@A@@@BA@@A@@@@C@@A@A@@@A@@B@@@@AB@@AA@@@@@@@AA@@@AB@@@AA@@@@@A@@@@@A@@@@@@@@@@@@@@@A@@@A@A@@A@AA@E@@@AA@@@A@@@A@A@@@@AA@@@A@A@@@@@AA@@A@A@@@A@@@A@@AA@A@@@@@A@@@A@@AA@A@@@@@A@@@A@@@@@AA@@A@@@@@A@@@A@@AA@A@A@@@@AC@A@A@@@A@@AA@A@A@A@@@@AA@A@C@@@AAA@C@A@@A@@AAA@A@@A@@A@@A@@A@@@@@@AA@A@A@@@A@@@A@@@A@@@@@AA@ACAEAUFAB@B@BAFC@@@AB@@@@@AC@@AA@A@A@@@AC@AAA@AIAC@AA@@@@BE@@FC@C@EBBG@CE@ALG@@@@@@@BJ@BBF@@@@@@@H@DBB@B@@@FBD@B@@@BBL@HBHBDFX@@@@@B@@@@BB@B@@@B@@@@@@@@@B@@@@@B@@@@@@B@@@@B@@@@@B@@@@@@@B"],"encodeOffsets":[[89605,45125]]}}],"UTF8Encoding":true});
}));