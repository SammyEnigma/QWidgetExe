(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('嘉峪关市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"620200","properties":{"name":"嘉峪关市","cp":[98.277304,39.786529],"childNum":2},"geometry":{"type":"MultiPolygon","coordinates":[["@@@@B@D@B@D@DADCFCDEDAPOHCBABA@@AAAA@AAAB@BGBC@C@@ACAAAEAGBGBIBCBA@ARCH@DABAB@JABA@@@A@CCEGI@@@AJG@A@@SQYUMKCAAACA@A@@BABA@A@@AAAA@A@A@@BABABABEBADEBC@A@A@ACCA@GEIEC@EAC@C@AACAECSK_MMEiQWIWIoUUICAAA@A@CBGDIBCBEBEBABAJEHEPGHAFALCFABARKDCDCBA@A@MBG@@B@B@B@B@@AB@@M@A@@IEGICCEACCGGECACAEA@@G@EACEMACAEACACGEEEECCBCDADEDCBGBKBKDKBGBA@CAGCC@KBEBEDSLGFEDEDEFEFEBGDCBEBI@GBIDGDGJEDOFCBAF@DDFBDBB@BA@C@CAA@CB[LOD[@_AWGSQKOCKAE@@ĳDC@A@ACOGqSIAA@@A@QPEHCFGLGJEFCFABABCBEBGBEBGAC@A@CBGBABC@E@CAEB_HC@EDCBCBA@[@O@ABA@BB@@LHTLhXjXJF^RhVhXFDJPPZJPDBNFZLDB`PBB@BCFSTKL}@BBBLPDBLFNHBBFDDBRHZJHD@B@@@BABA@ODKDM@IBIBA@@@@BB@BBD@BB@@@BAB@B@B@@DBFBFBB@B@FDBBBB@B@HBFBBBBB@N@B@FBDBB@B@F@B@BBFF@@DBHBD@JAD@D@D@BB@@BB@BAFEJADBBDJBDDJ@DADINCFEBAD@B@BBBDBB@B@Ċy^AÂGEXAF@FBB@@A@@AC@A@@@@BA@@HBB@JAH@D@B@B@HCF@DAPBJ@JBJ@D@N@B@BBBB@@B@BAFAD@B@FBB@FBFDJBHDBBD@@BB@BAHAB@JAB@B@DCFCBAD@DAHCB@J@VAH@DBB@JDFDHDHBJDBBBB@@@B@DBB"],["@@CCAAAACCA@ID@BXHB@AA@@"]],"encodeOffsets":[[[100831,40930]],[[100209,40671]]]}}],"UTF8Encoding":true});
}));