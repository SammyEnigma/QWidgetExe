(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('万宁市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469006","properties":{"name":"万宁市","cp":[110.388793,18.796216],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@cšO@cFqDa@_EeEQMWWU_OgKmKOCAACY@sHA[AEGCOAĵaKAI@KBGJIJGBQAWsW]QbABC@C@I@CBA@C@A@E@C@GBCBAB@BAD@DA@A@EBC@C@A@A@AAAA@AAAAAGAA@AAEEACEACAA@ABCDEFABABA@C@@BGLEJADABA@A@CAE@G@CBIJGHCBCBCFAB@DABA@CBG@I@K@C@AAEAA@A@CBEDGHEJAB@BAL@D@BCBGFABETCJ@HCNAH@HADBFBDBFBD@B@DEN@F@H@FBBBD@F@HRFLBBB@@@B@FBD@B@BAD@DBBDBFDBBBFBFBBB@D@B@B@DAHGB@D@B@DDBDDHBDDFFFBBD@D@@@BDABCD@B@B@BBD@DBFB@BBNDB@BBHFJLJLBJENEFEHGRALIPGHGHMLKVMRIJFJNFXJTHHDLFPFHDLLDL@HATFPJHf\\NJHFJJFF@HAHBFBBDDBBFFBBBB@B@BJRDDB@BEDCDAFADCDIBEBADAFAD@F@DBB@BD@DABABCF@D@F@JBBBBB@DBDAD@D@BA@A@AAEAA@CAC@CBABABABAB@B@B@B@FDBBB@B@B@BAB@@@FB@@HAB@BBDBBBBBBB@@B@@ADABABABC@ABA@ABA@ABA@ABCDCFEBEBCDA@@B@B@@AZFJDJFRBD@DCF@HDNFFDJJDH@B@BB@@@D@B@@@BDB@B@B@@ADEB@D@BBD@B@B@DBBBBBF@D@D@B@FBB@DB@B@B@@B@@@B@B@@@@BBB@BB@AHBHAB@B@B@B@BD@BDNBJBTHZF\\LPLLHPHNHRHV@LBPLLPCRCPPLR@PILKFGHEF@LFJRFHNP@AB@BCD@B@D@BBDBB@@BB@B@BA@@D@@@BA@KDGLEVA®E"],"encodeOffsets":[[113266,19543]]}}],"UTF8Encoding":true});
}));