--
-- 由SQLiteStudio v3.1.1 产生的文件 周六 十一月 16 21:34:39 2019
--
-- 文本编码：UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- 表：IpcInfo
CREATE TABLE IpcInfo (IpcID INTEGER PRIMARY KEY AUTOINCREMENT, IpcName VARCHAR (20) NOT NULL, NvrName VARCHAR (20), IpcType VARCHAR (10), OnvifAddr VARCHAR (100), MediaAddr VARCHAR (100), PtzAddr VARCHAR (100), RtspMain VARCHAR (150), RtspSub VARCHAR (150), IpcPosition VARCHAR (15), IpcImage VARCHAR (20), IpcX INTEGER (4), IpcY INTEGER (4), UserName VARCHAR (20), UserPwd VARCHAR (20), IpcEnable VARCHAR (2), IpcAddr VARCHAR (50));
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (1, '香港卫视', '录像机#1', 'other', NULL, NULL, NULL, 'rtmp://live.hkstv.hk.lxdns.com/live/hks1', 'rtmp://live.hkstv.hk.lxdns.com/live/hks1', '121.543420,31.226604', '无', 5, 5, 'admin', 'admin', '启用', '测试地址');
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (2, '香港财经', '录像机#1', 'other', NULL, NULL, NULL, 'rtmp://202.69.69.180:443/webcast/bshdlive-pc', 'rtmp://202.69.69.180:443/webcast/bshdlive-pc', '121.525885,31.218142', '无', 5, 5, 'admin', 'admin', '启用', '测试地址');
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (3, '韩国频道', '录像机#1', 'other', NULL, NULL, NULL, 'rtmp://mobliestream.c3tv.com:554/live/goodtv.sdp', 'rtmp://mobliestream.c3tv.com:554/live/goodtv.sdp', '121.535885,31.218142', '无', 5, 5, 'admin', 'admin', '启用', '测试地址');
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (4, '朝鲜日报', '录像机#1', 'other', NULL, NULL, NULL, 'rtmp://live.chosun.gscdn.com/live/tvchosun1.stream', 'rtmp://live.chosun.gscdn.com/live/tvchosun1.stream', '121.545885,31.218142', '无', 5, 5, 'admin', 'admin', '启用', '测试地址');
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (5, '美国卫视', '录像机#1', 'other', NULL, NULL, NULL, 'rtmp://media3.sinovision.net:1935/live/livestream', 'rtmp://media3.sinovision.net:1935/live/livestream', '121.525885,31.258142', '无', 5, 5, 'admin', 'admin', '启用', '测试地址');
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (6, '美国中文', '录像机#1', 'other', NULL, NULL, NULL, 'rtmp://ns8.indexforce.com/home/mystream', 'rtmp://ns8.indexforce.com/home/mystream', '121.525885,31.268142', '无', 5, 5, 'admin', 'admin', '启用', '测试地址');
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (7, '本地摄像头', '录像机#1', 'camera', NULL, NULL, NULL, 'dshow://:dshow-vdev=\"Default\"', 'dshow://:dshow-vdev=\"Default\"', '121.545885,31.238142', '无', 5, 5, 'admin', 'admin', '启用', '测试地址');
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (8, '本地视频', '录像机#1', 'mp4', NULL, NULL, NULL, 'g:/mp4/1.mp4', 'g:/mp4/1.mp4', '121.535885,31.238142', '无', 5, 5, 'admin', 'admin', '启用', '测试地址');
INSERT INTO IpcInfo (IpcID, IpcName, NvrName, IpcType, OnvifAddr, MediaAddr, PtzAddr, RtspMain, RtspSub, IpcPosition, IpcImage, IpcX, IpcY, UserName, UserPwd, IpcEnable, IpcAddr) VALUES (9, '摄像机#9', '录像机#1', 'other', NULL, NULL, NULL, 'rtsp://192.168.1.128/0', 'rtsp://192.168.1.128/1', '121.515885,31.238142', '无', 5, 5, 'admin', 'admin', '启用', '虹漕路421号3楼电梯口');

-- 表：NvrInfo
CREATE TABLE NvrInfo (NvrID INTEGER PRIMARY KEY AUTOINCREMENT, NvrName VARCHAR (20) NOT NULL, NvrType VARCHAR (10), NvrIP VARCHAR (18) NOT NULL, UserName VARCHAR (20), UserPwd VARCHAR (20), NvrEnable VARCHAR (2) NOT NULL, NvrAddr VARCHAR (50));
INSERT INTO NvrInfo (NvrID, NvrName, NvrType, NvrIP, UserName, UserPwd, NvrEnable, NvrAddr) VALUES (1, '录像机#1', '海康', '192.168.1.255', 'admin', 'admin', '启用', '虹漕路421号');

-- 表：UserInfo
CREATE TABLE UserInfo (UserName VARCHAR (10), UserPwd VARCHAR (20), UserType VARCHAR (10), UserAdmin VARCHAR (10), PRIMARY KEY (UserName));
INSERT INTO UserInfo (UserName, UserPwd, UserType, UserAdmin) VALUES ('admin', 'admin', '管理员', '');
INSERT INTO UserInfo (UserName, UserPwd, UserType, UserAdmin) VALUES ('feiyang', '123456', '操作员', '');

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
