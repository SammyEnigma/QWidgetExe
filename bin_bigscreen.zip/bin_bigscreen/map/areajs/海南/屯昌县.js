(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('屯昌县', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469022","properties":{"name":"屯昌县","cp":[110.102773,19.362916],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@@@BABAB@B@@@@@B@@B@B@BDB@@@@@BBB@@B@@@BB@@B@B@B@D@@@@B@@@BAB@@B@B@@@BD@@B@@@AB@@B@@@DBB@@@@BB@@@ABA@@B@@@B@@D@D@@@@B@@@DA@@@@@@B@BBDAB@@A@@B@@@BB@@BD@D@B@@@BBB@@@BA@@@@BBB@@BBB@@B@@B@@BB@B@@B@@@B@@AB@@BB@B@@BB@@AB@@@BA@@BA@AB@DBBBB@@@D@D@@@B@BA@A@A@EACBABEBCDABAD@@A@C@AAC@CBEBC@A@ABA@A@@ACAE@C@A@AB@BAB@@CA@AAA@CA@@AA@A@K@ABA@AFAHCFADADAB@FED@DADBD@D@B@BABAHCBA@@B@@@D@FADAFAPQJQ@KKIQBMIAK@W@QIQOCSDOHQBKGIMKIMIKQAI@]@Q@C@@CCAAAC@CBC@CBC@ABA@@BCBC@C@@DG@CAE@C@EFEDADGFED@JFBADA@@D@BACCACFGBIAEEGGCCEACDIDAHABACCCEDCFGJBJDBBHBB@HAB@BB@@BBBDFGDADEBEDAF@FBBADGBG@ACEAGDCCI@UAUCS@EDYCWBKDME@M@MCGCICYGUIQEMHOPILI@GKCOBKDG@EGM@M@OKSIKEGCCGGCCC@KJE@IDO@S@MAQEEAQAKHEHAF@JGPGHKHCDAB@BAFBFBBABA@A@A@@A@@AACBC@C@A@CB@@A@AAA@ABA@@BA@A@@B@@AA@@A@A@A@@@A@A@A@ABAD@B@@@@ABA@A@@@@B@B@@@@@@@BB@@@@B@@@@@@CBA@@B@BAB@@A@AA@@@@@B@@ABa@GA_CGN@F@JBJ@HGNKNMLOFMJKBKAWAG@GHIJCFKNGLKNEFGDMBM@CC@@A@CBABCDABABC@E@E@ABORAD@BBFB\\@DDBCF@DBDBDBP@@@D@FBD@DCBCBBBBDBBB@BBDBBBBB@@DBF@LJBNAHFPFJFJHDHFF@DBDABAB@B@@@@B@@@B@@BBB@@@BABAB@B@@BB@HIBCDCB@B@H@B@B@BBFDHH@@B@D@B@B@BBD@B@BBBBBBDD@B@B@B@@@@@@@@@@C@AA@@@@A@@@@B@BC@@@@@@B@@BBBBB@D@BBB@BB@B@B@BCJ@BA@@@CAC@A@A@A@@BAB@@BBD@H@BBB@DB@@@B@B@@@B@@@D@D@B@D@DBDBBBB@@B@@@DC@@BA@@D@B@HBDBD@B@B@DAD@B@B@BBB@@B@B@BABCFABA@A@CAAAA@A@ABC@ABA@@B@D@B@BBBDDB@B@B@DDDB@BB@@B@B@F@B@@BBBBDDBB@B@B@BA@AB@B@B@@FBF@BBB@@D@@ABE@A@ABEFADAB@B@@@BBBBD@D@FABVBNDLBJAN@HCNCJCRANBPBRDJCJEBEBCBOBIHKNCTFTHNJDJ@JGNDPRJLBR@RAPDPJAJCHGH@BA@@B@@@B@BBF@B@@@BB@@@BB@@@D@@@B@@AB@B@@CB@@ADA@@AA@@@@BA@@@@@AA@@A@@@A@@BA@@@@BBB@@BBB@@@@BAB@@@@AD@BCB@@@BAB@@@@@@@B@@@@B@@@@@ADABBB@@D@BBB@@@BBB@B@@@@@B@B@@@B@BA@@B@@@BA@@@@BBB@AB@@BB@@B@@@@@@ABB@@B@@B@@@BB@@@@B@@AB@@BBBA@BB@@@BBB@B@@B@@B@@B@@BBB@@@@@BA@@B@B@DA@@B@@@BB@@@@BA@@@@@@BB"],"encodeOffsets":[[112781,20030]]}}],"UTF8Encoding":true});
}));