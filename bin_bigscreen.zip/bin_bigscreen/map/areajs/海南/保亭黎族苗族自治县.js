(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('保亭黎族苗族自治县', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469029","properties":{"name":"保亭黎族苗族自治县","cp":[109.70245,18.636371],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@@@AAKKCCACAGECCAAAAC@CAE@GBC@CBCAE@CAE@@BABANAPCB@@A@AEYAC@A@A@AFCJCBA@AA@IK@A@E@CBCBAFCFCB@D@HBNDJFHDB@B@@@@@AC@E@IBGBEBAB@DAH@L@F@B@@@@@AC@A@C@EBA@@BAFABAHOBAFEDCDE@@@CACCICA@AAG@AA@@@E@CBA@AAA@@AAA@A@CBADEBCBCBCBE@EBEAE@AAAA@A@CBA@ABA@AAA@A@CBAAA@AAACAAAAGA@@A@@C@CBC@@AC@AAG@AAG@EBG@G@EAGAAB@DIDAB@@C@A@@DA@@DABBB@B@F@B@DC@@BC@ABMFCD@F@@@B@@ABAB@B@DBHDH@B@@A@A@C@AFADG@A@ACE@A@@@@@ICAEGC@@@EAIE@@AMBABA@ABKCIIMACAAICKDAB@BABAA@AAA@CB@AAEAE@AB@@@BAF@B@DAFA@A@CACEGBA@AA@@CCCCA@E@IB@@AB@L@BA@AFABAB@@C@ABCBAB@BCCCAA@C@@BAA@C@A@C@@@KACCQAAC@GAGCEA@@ABABAA@AECMGC@A@G@A@@@@A@@@@@A@@AE@A@@@@BA@ABAAAAA@C@A@@@ABCBABA@AAA@@@@A@ABC@A@A@AA@@@@CCCCCEEI@GAC@ACK@A@OBEBABI@GAA@@CFCDEB@@CDEFA@CCEGEG@I@ABC@K@@C@A@G@@A@A@A@AAAAAA@AA@CDEBABA@CECEACB@@CD@B@@A@A@EAAAA@@@AC@A@A@A@@A@A@GBAAA@@@A@A@ABCBA@A@A@CACBEBADABABADA@@B@BAAA@@A@A@@ECAA@@@@A@C@A@@BA@@@AA@@ACCACAA@A@@BA@@@A@AAA@@A@@AAA@@@A@A@E@@@CAAA@@AAA@C@ABA@@B@@A@@B@@A@@@AA@@C@@@ABCFCDA@@BA@@@CAA@@@AAA@A@AAA@@AAAAAAA@AABIFA@EB@B@@@BE@A@@BA@A@A@AA@@ABA@A@AAA@A@A@ABCAC@AA@@CBA@C@@@CBAB@B@BAD@H@B@@@B@@@B@B@@ABID@BAJ@@A@AB@@@B@@@@ABA@KD@BEDAD@BA@A@AB@@@H@BAB@B@@B@@@BA@@BAB@BAB@HHBB@B@B@B@BB@BH@HABIH@B@JBBDB@@@B@BBN@BDBBBAFADBBDFBBJHBBBB@B@B@BAF@DA@BBBB@P@BAB@F@BAH@BBB@PBDAFA@CDGDEBABMBA@IBEBCBAR@BCFABCCE@A@C@A@A@ABIAGDCBABC@IFOCCAC@M@CDCBABA@EBEDEFEBABC@A@AAA@ABAA@A@AAAECC@A@ABAB@@AD@DDB@@BB@B@D@BAAABCDABBF@BAB@DABCDAB@DABAD@B@B@DADA@C@BDABCB@BBD@@@BBD@B@PAB@BED@DB@@BBBBB@B@@D@B@DABBF@B@H@D@F@D@BBDBFFDDDDFLBHBF@@BDFFDDB@BAFADAB@B@F@B@B@BA@ABAD@F@B@@ABABAD@DBF@D@@@BAD@F@D@D@FBNFDBHBDBB@@@BAB@BADAD@BADAD@D@B@DDBB@DBD@BD@LBD@DB@B@@@DCBCHADABABAB@B@DBD@BDB@@BB@BCHALCJ@DABCB@D@D@B@BHDBBDBHBDBBBBBBDBB@FBFBBBBFDB@@B@F@BBBDDJBDBDBDD@B@@@B@B@@@@A@A@@@@@@B@@@@B@D@B@DADAB@@@FBDBDAFADAB@@@BA@A@EAIAE@CA@A@C@A@A@C@EAAAAAAEBA@ABAD@B@F@B@DADAB@BABG@E@AB@BAB@BABABADGBEB@B@FAB@BB@@B@B@B@BCB@BADABA@EBADCFCFCBAB@@@@D@BBDDDDH@BBBB@@@FAB@@AB@@@BBBHDH@@@B@BABAD@D@B@BBBDDB@BB@F@BDD@BBB@B@B@BAB@@@BB@@@D@@@B@@@B@BAB@BBB@DBDBB@DAF@DADBB@DBD@B@FB@@BBB@B@D@FAB@DCDAFAF@F@BBB@B@D@DABABBB@@BBD@F@FBBBB@@@B@BCHADADAB@DELCLABEHAB@B@FAB@BGHADBD@B@B@BABAB@BABABA@AB@@BBHFBBBB@@CHAF@B@BBFBBBBB@BBB@@BB@BB@@@B@D@B@@CDEDCHAF@@@BBB@@BB@@@BBB@BBBDB@@D@B@D@B@F@B@J@F@LDB@@B@@D@HAB@DCDCB@DAB@@AHGHGFAFAD@BBLBL@FDF@B@B@DCDCB@BC@@@EDE"],"encodeOffsets":[[112409,19261]]}}],"UTF8Encoding":true});
}));