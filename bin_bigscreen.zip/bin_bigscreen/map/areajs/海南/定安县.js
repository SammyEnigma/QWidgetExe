(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('定安县', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469021","properties":{"name":"定安县","cp":[110.349235,19.684966],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@B@B@B@BB@@B@BA@A@@AAA@@AAA@ABA@A@@AA@AB@B@B@B@BA@A@CBEBA@A@AD@BA@@@C@A@@@AB@BA@@BEAEACCEIEGCCAA@@ABE@A@CCCCEAE@C@GAKAG@EBC@GBCB@FCDCBC@A@@@A@@@AB@@@@E@A@@@@@AB@@@@@B@@A@@@@@A@@@A@@@A@@@@B@@@B@@A@@@@@@@A@@B@B@B@@B@@@@B@@@@ABA@@@@@@@@@A@@@@@@AA@@@@@@B@@@B@@@@@@A@@A@@@BA@@@@@A@@@@@AA@@A@@@@@@@@@A@@@@@@B@@A@@@@@@@A@@@@@A@A@@BA@@@@@@@@@A@@@@@@@@B@@@@@B@@A@@@@@CB@@@@@BB@@@@@AB@@A@@@@B@BA@@@@B@@@@@@@B@@@@@@@B@B@@@@B@@B@@AB@@@@B@@B@@B@@@@B@@@@@B@@BB@@@@AB@@@B@@@B@@@@@B@B@B@@@@B@@B@@@@@@@@C@@@@B@@@@A@@B@BB@@@B@@B@B@B@BA@@@@@AB@@@@@@AAAACAA@@ACAA@C@A@CBEDEBEBAFABADAF@BABABABAD@B@B@B@B@B@@@@AD@DCD@BAD@B@B@BBBDBF@B@BCBBB@BBDB@B@D@D@B@DAB@BAB@B@BAB@D@BAB@DB@BBD@DDDFDB@DBB@B@BAFCB@FCDCB@F@B@D@BA@C@C@CBC@CBC@C@ABAD@DADADCDA@CCAAAECA@E@MCKCIGCGCEMIKEEECCAKDQ@KDIDCHCH@F@PHRFLDL@NARKTKHEJIFGBIAMAEGGUCOCSFQDIAKIIMAGAIEEGCIBK@UJM@KAKIECGIGIAGCKEIGEODEDGBGEIOAGMKGAIAO@GCGCKS@ODK@CAKEEKAMBK@KIEW@CCOEIEIDMHCHETIVGFEDKBK@IEIKAMACCGKAIAK@KDIHIDICOGGIAEDEFIFQAMIQQMACBKFIBICIGIAK@OLIFKDICMAI@DXCZ@FDTBV@VDJCDBHDF@BAHCHABEAE@CBAFCFCBEHACAA@@AAA@GBA@GAAAICIAEHCDDFDDABGBCBCJBDDFHDFHBFAJEHBDDDABC@@@CBABIEC@EFCHCBEF@F@DBF@DCH@@@DADAD@@AB@BAD@DAD@DBDBBDD@@@D@R@^BJLRNJLJJNLHRAPGTCPDJR@R@XBLNJRALJ@LIROREBCBEBC@@@A@@@ABGDABABA@C@C@CACBC@EFA@CBCBEBGDEB@BAB@B@L@BBB@@DBB@BBB@@DA@ABA@@B@B@DBFBD@@@BAB@B@BADAF@DBD@B@D@BC@ABCBADAFABBD@F@B@BABA@@@C@C@@@A@AACAA@@BAB@@AB@@A@@BA@@AA@A@@AA@@BA@@@A@@@@AAA@@@AA@@@AA@AA@AA@@@@AB@@A@AA@@A@C@C@@AA@@A@@@AB@@@BAAC@A@A@@@@B@@C@@@A@@C@C@@@@A@@@AB@BA@@A@@A@@A@CA@@A@@@BA@@A@@@AC@@A@A@@@BA@A@@@A@@C@A@A@A@@@AA@@A@@@AA@A@@@@CA@A@A@AA@@@@@A@A@ABAB@@AB@HABABABAD@DBD@B@B@FFBD@D@FB@D@DABCAC@@JAD@FC@CCCCACE@CFADAB@DBB@DBBDDDDFBB@DBBBDBDBBDBD@D@DAJAFB@ADITGXFHJ@JBHL@JHJRFNE@@B@@@FADEB@@@FCBCDA@A@@@ACC@A@ADG@CAABCDCB@B@B@BAB@@A@CAA@AB@B@BAD@DABADA@@B@LEJOLD@@B@BADCD@@@BA@ABC@CBAB@B@B@@@DBBBBB@BADADABA@A@ABAB@DADBBBBBBBFBBB@BBB@BDDFB@B@B@D@D@B@@B@D@D@NAF@BBDBBDDFBDBFBH@DDBBBB@BA@@B@D@D@DBDDDBBBD@D@B@BAD@FBB@BD@D@BBDBF@BABAB@@BB@BBBDB@D@D@DBD@B@D@D@DBD@FADADADAFABAFBDBBBDDDHDHDDFJLBDBFBBBBBFBB@DAFCDADADBBB@BD@DAF@F@HAF@FAF@BBBD@HBH@D"],"encodeOffsets":[[113028,20202]]}}],"UTF8Encoding":true});
}));