(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('东方市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469007","properties":{"name":"东方市","cp":[108.653789,19.10198],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@BC@AAKCOCAGAGAEBG@E@IAGCIICECCGCGIAC@EAS@M@EAEIKA@CBC@K@MAE@AAAAAEA@AAEBCBA@C@C@E@CBGBC@IBGDABA@AACCA@CAA@K@CAAAEGEGAEAAAAAAAEA@A@A@CBABKBE@A@A@@@ACAAA@CAA@C@EBKFCBA@C@GACAA@CBYBWEMCQEICKEIGSKQQWIUGSOKIQSQOM@OBMBKAKKGFILOPKDOGS@M@KAMBICUMGCTI\\ejqrapI^A^@TDTL^pp\\ZDFHT@FKÂA\\ADOLQLIRUK¦AJJJFXNZbtZVYJOHUAEBGBCHCDE@CDEDEBCBA@@FCDCHEBABC@ABCDKDGJGNGTELALANDJANCXITCXGHADAD@FDFDFBF@R@LBJDHFHFJBHBFCHEDEBEBAFADAF@HAJCRKLGJEHCF@H@H@FBDAHGJGFAJCJBFBDBHBF@P@PCLAHGHIDKDEFCBA@I@OBGDKDMBEDENOFEFAD@D@H@JCDA@ACECAACA@E@GAC@AAAABA@ADA@C@AAABA@AD@DADAFAF@B@DBDBD@DADABA@ABABA@A@ABA@ADABA@ABC@EBE@C@AA@CB@@AAAAACA@@CAAA@AACE@A@CBCBABAAABABA@CAE@CAAC@CAAAACBABCBABA@CAA@CAC@CAK@C@A@C@@HGLMB@B@D@DDB@D@DAFCD@DBBBBDBBBBD@F@H@D@F@B@DANGLIB@B@B@B@@@B@@@B@B@@@H@XGDAD@B@BB@@BABABIBCNgBA@@@A@GB@BA@A@@@A@A@A@E@@BE@EBC@CAC@C@A@@BCBC@@@A@ACE@A@A@A@A@@CC@@@CAC@AEC@AAA@AB@@CAAACAACE@ACA@AAA@A@E@K@E@@AAACA@CAAAAA@@AC@GAA@CBA@A@ABAB@DAB@B@B@BAB@@ABABCFCDA@ADC@@@ABA@ABCB@BCBAB@BAB@@@B@BAB@@@BABAB@DCBABA"],"encodeOffsets":[[111745,19332]]}}],"UTF8Encoding":true});
}));