(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('中山市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"442000","properties":{"name":"中山市","cp":[113.382391,22.521113],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@IBW@ODMDG@CAA@CAACCAABABC@AAAAAC@AA@CACBEFCDC@ECAACACAGAACBM@GCAC@CCECAE@CBEBCDCDCAEBEACCA@CFEBC@ABA@@@@@A@A@EAAAAAA@A@CBC@@@AA@@@A@@CBEB@FADAAC@CBAB@DABABAAABCDABA@AACCAOGC@CAEBC@AC@AACA@E@AAEACAA@AA@AFCB@@ABABABABCB@B@TUDCBCBAB@B@B@@@@CAA@CA@BABCBAB@D@BA@A@C@ABCBCD@D@B@BA@EBAD@@EB@@A@A@C@@@@AAA@@A@AACACIEEA@@@@CAAAC@A@ABA@A@@AAAC@CBE@CACAAG@GDCDABABA@AC@GAEAEAICCACAEAA@ACEGEAKCMEEAOECCAAA@G@GBIBCFIJOTMREFA@A@CAAAA@ADADA@EDAAC@ABCBA@SJMJGFEFCHCDCJCJELCLM\\ITCLAFAR@RGLEJMLclQRGJEHWNAJCJCJAH@H@L@N@V@FELCFEHEHELEZEJKRKN@B@@@@IPIPKLOLSVIHD\\CXCTQ`UXEPKHBHA^FZFL@@@@@@BBLABB@@@H@FC@CACJABC@ADD@@BBBB@D@CFEFBBBDDA@@@@@@B@@@@BD@B@@@@@@BDB@F@@BAB@@BB@BABA@@@DEFBBBCDCDCD@BABAD@DCBAB@D@B@FBD@DBD@@@ADAD@FFHBBDD@D@B@@@B@HJBPPJLBBJRHLFLBNFFDBDBLALGHIFKFEDCJBHJFHHFFBN@JCJAJBNBPBRF@BAD@@@@@B@B@B@@BB@BBB@BB@B@BBB@BBB@BBB@BB@@BBBBB@@BB@@@@@B@@BB@BBB@DBBBB@B@BBB@D@BBB@BBDHHHPKDANITK@@JEHC@AFCB@RIJCRER@H@DANADAfKEM@@@@AANKVOTO`S`UdYAQEAC@C@@A@AHMJOFIPWFMFEHKFG@AFFHEFFFCBBDENIFCHAL@DAPIJELKfVuDKTAjATBoGk}I@"],"encodeOffsets":[[116295,22950]]}}],"UTF8Encoding":true});
}));