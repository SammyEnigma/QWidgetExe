(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('图木舒克市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"659003","properties":{"name":"图木舒克市","cp":[79.077978,39.867316],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@kKe@gD[AKKSYEG@IMMSKU@KA[GmIkIIACE@KAY@S@EQC_CcEwI_EW@KAUFOBeAi@EDKLSPEJEDC@GCSGGCE@IDOFDDHHHJHNDHBFEHCDEA[IUESASEgAU@MDGDCF@FBDDDBBF@DBBBBB@@AD@DABAD@BA@@B@@@@@D@@ABAB@B@B@@@BB@BB@@@B@B@@AB@@A@AB@@@B@@AB@@@@@B@@CBE@A@G@C@ABA@AD@BADABCB@@E@CAEBKDCD@DFHADCDGFIHEPCT@DFDLF\\JdTRJDD@FBDFDHDLNLLLDRHVFHBHNABBB@B@BCBABA@@B@@ABAB@B@BB@@DBB@@@BA@A@AAAB@B@@@BB@BBB@@B@B@@@@B@@@B@B@D@FD@@@@@@BBHFH@HCBCCGCCAE@A@G@KFE@AEC@ADCHADCJK@KCMCGIECAAKDCBABBHBJBJAFAHGJKNI@ECMGMICI@ICBADEFEHMEKGGSEACAABEBEJGFILKFQNOFCFBDFDFHBJBDDBDBH@RBNDLDPFJHJJDNDJBFEHMGE@CDAFBFHFFDAJGHAFDBF@FETIPAJG`ATAHp@J@D@DZBNf@¸@Z@B@@@@B@BBB@BDBB@@B@@CB@BB@B@DDBB@@@B@@AB@D@@@B@BB@DBBB@@@@@BABAD@BA@ABA@ABA@MBC@@@@AA@CAEAC@C@A@I@C@C@EBEBG@C@EBA@EBG@A@EBC@ABAB@@CBABEBCBA@A@A@@BA@A@CB@@ABCBEDABGBABCBA@@@CD@FAB@@DB@DHDJDJHHFBF@NFHDBH@N@FBNFLBNFNDN@HAJEB@B@@FADCD@@@@@BADIFGFCF@DFBBBADGDOHODE@CAC@C@CHEHCFDDJFZJ^NZJFDBD@H@FFTJlBDJDNBPBXBJDBBCHENMRCNORELAHBBDD\\J^FdFX@XF\\F~FVDnD^FjD`FL@hFLHrHzJ®NHnHTBF@LITSDCDENINMTQVW^[VURQLWJYH[NiJeLkBM@EIIkaocKEO@OBUHoLG@aJsN]HaHc@gCKÁMO@AA@EJIdcNMBICEGIMEEEAGBEHIPAPBHBB@@DBB@F@BB@@@B@BA@CD@BAF@B@D@@@FABAB@@AAA@G@C@E@CA@C@A@A@AB@@A@@AA@C@@@A@A@AA@AA@@@A@AAAAA@C@ABC@A@AA@@ABA@@@@@@@@A@@@@A@A@ABA@A@@@AAA@C@A@A@A@A@@@A@BAAA@@CAA@AAC@AA@AAAA@@AA@@@C@C@A@A@E@@@A@AA@@@A@@@AA@@@A@A@@@AAAC@@A@@@A@@@@B@@@BC@AB@BA@@@A@@AB@@AA@@@A@A@AAA@A@@@AA@A@@A@@@AGOACOCgIaGKC"],"encodeOffsets":[[81092,40674]]}}],"UTF8Encoding":true});
}));