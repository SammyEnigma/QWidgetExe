(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('石河子市', {"type":"FeatureCollection","features":[{"type":"Feature","id":"659001","properties":{"name":"石河子市","cp":[86.041075,44.305886],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@AB_FA@AB@B@@JN@D@@@B@@A@A@CAGCA@A@@@@@@B@BBBFDZR@@@BBBAB@BA@A@C@C@E@ABA@A@GBCBABA@CBA@A@AAA@@A@@C@AAAAA@E@CBA@AAA@A@GAGB@@A@A@A@A@AAABCAABA@@@C@C@@@A@AACBGAA@@@@@@AA@AAC@GBC@CBCAA@CDAAABA@A@ABC@CAA@A@A@A@@@G@@@AB@@@@B@@B@@AB@@@@@F@B@BADBB@BBB@BAB@BABAB@B@FAB@BA@ABAB@@A@E@A@AB@@@DAF@BBB@BBBB@BB@B@@@B@B@B@@BB@B@BBDBBABBB@BABAB@BAD@B@FAD@BGTAHABAB@BBBCFAB@B@BA@@D@@FBB@BB@B@@@BABCBABA@@@AREB@LCh@B@FEDCFEBD`OBG]WDHfQFOFILQHFn@LBl@LDlBL@JBLNCNEVKhA^IF@NEFD@@@@@F@DAF@@BAJIBBDBDC@@D@NBH@D@F@HHBBNPFP@FBDBBFHLL@@BBFBFB@DB@JBD@B@HBHBLBJBJBD@D@N@P@N@FBHAF@FAB@@@DADEDCDEAAAAACACAA@A@AA@@C@A@@AC@AA@BEBCDKDEBCFEBC@CAKBE@EBEBCAA@K@IBQBA@C@@@ABABEBC@G@ABGAGBEDGHUBEBCDC@CAG@C@GAEAC@ABC@C@C@C@AEKAC@ACCA@@C@A@AACAACEECAA@A@CAK@AACBC@CBIBC@A@AAE@GBE@C@CA@AAAI@ABCBA@A@EBC@E@ABGBE@CBE@ACOCK@ACEAGCCCCAAACAACECC@AA@@A@A@A@@@A@@@A@AB@@A@AB@@A@ABA@@BA@AB@@A@A@A@@@ABA@A@@@AAA@@@AAA@AA@@AAA@AAAA@@AAAA@AAAAAAAA@@AA@AAA@@AA@AAA@@AA@AAA@@AA@AAA@@AA@A"],"encodeOffsets":[[88163,45185]]}}],"UTF8Encoding":true});
}));