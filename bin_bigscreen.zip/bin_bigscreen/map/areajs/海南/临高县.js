(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('临高县', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469024","properties":{"name":"临高县","cp":[109.687697,19.908293],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@X|VLR~p^\\NJNDZF^FND^@^NFHNJJDNDP@TCN@PDTDL@NCTK^cZUNCXAPBLDLHNJNFNDR@LALG\\Kd£JQJCPAAK@K@QCKCIKMEAADGB@DCDAAE@CB@BEPKOCBE@E@EABADCBCBCBA@ABC@AACAAAAC@ACAACCDAH@FADAFG@ADCBADAD@FBD@D@@@DA@ABA@A@CB@BAB@DBB@BAF@B@BA@AAE@I@C@C@AAAC@I@AAA@AI@EFAHAHADK@CGAAACAAC@IESBCHAPGBADGHCFG@CCKCI@IEKAAIAAADKDMEMAWGKIKGIIIEKAO@UIQCM@ICIKEG@KCMGEGAOCCKIGEAIFMHATEDGOIKACBMDIAKBKHEHG@@@CA@EGSIMAGEGEAE@CAE@IGCBE@E@GDCAADEBCDAB@BD@B@B@D@@@@DBBDD@B@@@BB@@BAB@AAC@AA@A@A@A@@@@@D@@A@@@AA@@AAAA@CBABAB@@AB@BAB@@@@@A@@AAA@@@B@@@B@@@BADA@@BA@@BA@@@@@@@@EAA@A@ADQFQIIIEBADAB@@@@CDABAD@BA@E@EBAACB@FC@AABCDADCAAEFA@A@@DADA@@@@EA@A@BBAB@@@B@B@D@@AA@@@BABCDEBCB@@@CBA@@DEBAA@AA@CB@@AABABBB@B@BA@A@A@@DE@BD@BCFCFA@BIAA@A@BCFBBAD@BCBDHIBBJAFFJDDTF@BEAC@E@ABA@C@CAC@G@EACFABEC@EC@EJCDE@IAM@AACECACDM@CFGBIPUIE@GBBHDFFHENCHOJGFFF@PITCFC@A@CAABA@CFCJBN@JD@BABCHEH@DB@@@@FBDDFFJFBBAJLCB@FD@FDDDFBH@N@JABBFBH@@@@@HGVIFMBIBGFCLCPCNAJ@LBP@FBVALAHC^CJOF·`"],"encodeOffsets":[[112127,20351]]}}],"UTF8Encoding":true});
}));