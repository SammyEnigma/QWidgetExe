(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('白沙黎族自治县', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469025","properties":{"name":"白沙黎族自治县","cp":[109.452606,19.224584],"childNum":1},"geometry":{"type":"Polygon","coordinates":["@@HAHAFAFCDA@@FADGFADCDAF@H@F@HBBADABCB@BCB@BBB@DFBLDDJBFGLSBIDGHEHCHAJMBEHMFEJAL@J@JBJ@HOIGICEECG@@AAAC@A@G@AAC@A@ABAB@BABCBADADAB@D@BBDBB@FBBBD@BBB@D@BADABAFADCBABABCBCBAF@D@D@B@BBBB@B@B@BBBDBDB@@B@BC@A@AB@B@B@@B@BBBB@D@BAB@DB@@BABA@ABABCB@B@JBB@B@@@BA@C@AFEFAB@DABA@@BB@@@BAF@@@BB@D@D@FAB@@@B@B@@B@B@@ABABA@@B@@@BD@B@B@B@B@B@B@D@B@B@@@B@@@B@B@BD@D@B@@AF@@@D@BBB@@BBB@@@DA@ABA@@@A@@@@BA@AB@@@@C@A@A@@BAD@BA@B@@@@@@B@@@B@BD@@@B@B@BBB@@@@B@@@@AB@@A@CBA@AB@@@@@DD@B@B@BBB@@B@B@DB@@@B@@@B@@BB@@BABA@CBA@@AA@ABA@AB@@@BDBBB@@@B@DABABABAD@FA@@BCBABABCBA@CBE@A@ABA@AB@B@DAB@@@B@@DBB@@@@BA@@@C@AA@@@@@@AB@@@@@DB@@BD@@@@B@B@@@@A@A@ABAB@@BDDB@@@@B@@@B@B@B@@@BA@@@@@AB@@@B@@B@@@B@@@@@B@@@@A@@@A@@@AB@B@@B@@@B@@@@B@B@@@@@BA@@@AB@@@@@@@B@@A@@@@BA@A@AB@@@B@@@@@@@@@@BB@@@@@@@B@@@@@@@B@@@BB@@@@@@BA@@B@DAB@@@BA@@@@@A@A@A@AAA@@@ABA@AB@BA@@BA@A@@A@@AA@@ABADABAB@B@BADAF@D@@BB@DADABBBBBBDDD@B@B@@@B@B@@@B@B@@BDB@BBABAB@@@D@BAB@BAB@@@BA@@B@JFFFLHFDFFAHAHFNDDHJFJFHJ@LARDJJD@BEFGFCBEEEGEBEJIDG@ABADADA@E@C@A@@B@B@D@DABABABC@A@AAA@AA@@AG@EC@ABAAEDGD@@CEGACBIA@CAEBGE@C@EAEGC@C@ABGA@CBC@@@C@E@ACCK@@EIA@@A@@BAF@NCFADBDBDBHBHBRFDAH@BAAAA@CABA@ABA@@B@B@B@BBDB@@B@FBDBDDD@BB@@DB@BD@B@HBDDBBBBF@BC@CBEJCBGBEBABCBAD@BA@A@ABEDCBCDEDA@CBCFA@ADCBABAJCBA@CBCDCDCBCBG@EBCBEBADAB@@@BBBBDDF@@BBFBB@DBBFBD@FAFAB@@A@A@E@E@E@EBA@C@EBM@CBAPQBAFCDADCDA@ABA@EBAB@F@B@BBVBJBF@FBHDFBFADA@A@AFSJSLMAGAC@@BCBC@CB@DGBCJEFCDABA@C@CAEAG@C@CBABC@A@AAAKOKMAA@@KHGFCDABG@G@E@A@CAEECGCEAE@EBE@G@AA@AACAC@AACACCAAGAC@CAA@C@ABA@E@@AACCACAECGCCACCAC@E@CFIBKBC@ECGCCCAEAEAE@GFMHaROFIBE@IAGCCCEECE@QAEAG@E@GA@AAC@EACAEEIEGCC@CBC@CBA@@@A@CCAAA@G@CBA@CBCBABA@C@CAGCEAEAE@A@ABA@ABADCBAB@@AAAA@GEQAOAEAG@CACACAACAC@CA@@C@A@A@A@AAEAAAE@EAA@C@C@CBA@A@A@A@AAA@@CAAACAC@AAAA@AACA@@AAA@CCAC@ACCCC@AA@@A@@BCBA@A@@@@A@AAA@AAGEGEAAA@A@A@A@A@@@A@AA@@A@AA@AA@AAA@CAA@AA@A@@@C@A@A@C@@ECECEACACAA@A@ABABADADCDA@IBKDE@ABEBCFA@ABA@A@ECA@A@A@ABABA@A@ABC@GBEBIDEBA@ABC@ABCBAB@@A@@AA@@AEBABA@@@A@@@A@E@A@A@AAABA@@@AD@D@@@DBH@D@DADCDABABAB@BBBDFFHDF@BBB@F@DADABCB@@ABAD@B@BBD@B@BAB@DBB@BBJ@BAD@BA@@BA@@D@BBDA@AFAB@F@DCB@@@B@DDB@DBH@F@BCF@D@D@B@@A@@@A@AB@@ABA@A@@@A@@@ECCA@@@@A@@BA@@@A@E@A@A@A@ABC@ABCBADCD@BAB@BA@A@A@A@CAA@A@E@C@ABABCBCBA@@@CAAAA@A@C@ABADCJABCBGFGBEBA@A@CAA@OIGAGAIBCHANCLAFALKXEHAN@DDDBNCLIJQJEFSLKNIRCLETBLHNHRHNDPBFFNFNBNBRIPGHGJEHEDENAFADIACACAK@SLEJEJCTILOBMAQFKFIHIJERBRDHHHJL@VELCJCN@RAHAJ@FBF@F@BFFHDDJBHAJADELEHAH@H@NDLBHFFH@HAB@F@B@D@J@"],"encodeOffsets":[[111689,19955]]}}],"UTF8Encoding":true});
}));