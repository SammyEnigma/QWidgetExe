--
-- 由SQLiteStudio v3.1.1 产生的文件 周六 七月 27 11:06:39 2019
--
-- 文本编码：UTF-8
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- 表：t_1_1_mold_prod_total
DROP TABLE IF EXISTS t_1_1_mold_prod_total;
CREATE TABLE t_1_1_mold_prod_total (internal_id  INTEGER(11) NOT NULL,name  TEXT(255),prod_1  INTEGER(11),prod_2  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_1_1_mold_prod_total (internal_id, name, prod_1, prod_2) VALUES (1, '设变', 14, 12);
INSERT INTO t_1_1_mold_prod_total (internal_id, name, prod_1, prod_2) VALUES (2, '修模', 20, 25);
INSERT INTO t_1_1_mold_prod_total (internal_id, name, prod_1, prod_2) VALUES (3, '新模', 40, 25);

-- 表：t_1_2_mold_prod_monthly
DROP TABLE IF EXISTS t_1_2_mold_prod_monthly;
CREATE TABLE t_1_2_mold_prod_monthly (internal_id  INTEGER(11) NOT NULL,year  INTEGER(4),month  TEXT(4),prod_1  INTEGER(11),prod_2  INTEGER(11),prod_3  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (1, 2018, '5月', 32, 54, 80);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (2, 2018, '6月', 42, 34, 33);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (3, 2018, '7月', 45, 62, 44);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (4, 2018, '8月', 23, 38, 65);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (5, 2018, '9月', 12, 12, 77);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (6, 2018, '10月', 22, 33, 34);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (7, 2018, '11月', 23, 45, 22);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (8, 2018, '12月', 32, 65, 43);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (9, 2019, '1月', 12, 23, 65);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (10, 2019, '2月', 21, 77, 55);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (11, 2019, '3月', 22, 87, 33);
INSERT INTO t_1_2_mold_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (12, 2019, '4月', 23, 45, 34);

-- 表：t_1_3_wp_prod_total
DROP TABLE IF EXISTS t_1_3_wp_prod_total;
CREATE TABLE t_1_3_wp_prod_total (internal_id  INTEGER(11) NOT NULL,name  TEXT(255),prod_1  INTEGER(11),prod_2  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_1_3_wp_prod_total (internal_id, name, prod_1, prod_2) VALUES (1, '其他', 8544, 10000);
INSERT INTO t_1_3_wp_prod_total (internal_id, name, prod_1, prod_2) VALUES (2, '钢件', 1000, 5002);
INSERT INTO t_1_3_wp_prod_total (internal_id, name, prod_1, prod_2) VALUES (3, '电极', 2000, 3000);

-- 表：t_1_4_wp_prod_monthly
DROP TABLE IF EXISTS t_1_4_wp_prod_monthly;
CREATE TABLE t_1_4_wp_prod_monthly (internal_id  INTEGER(11) NOT NULL,year  INTEGER(4),month  TEXT(4),prod_1  INTEGER(11),prod_2  INTEGER(11),prod_3  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (1, 2018, '5月', 32, 54, 23);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (2, 2018, '6月', 42, 34, 30);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (3, 2018, '7月', 45, 62, 44);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (4, 2018, '8月', 23, 38, 65);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (5, 2018, '9月', 12, 12, 77);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (6, 2018, '10月', 22, 33, 34);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (7, 2018, '11月', 23, 45, 22);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (8, 2018, '12月', 32, 65, 43);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (9, 2019, '1月', 12, 23, 65);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (10, 2019, '2月', 21, 77, 55);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (11, 2019, '3月', 22, 87, 33);
INSERT INTO t_1_4_wp_prod_monthly (internal_id, year, month, prod_1, prod_2, prod_3) VALUES (12, 2019, '4月', 23, 45, 34);

-- 表：t_2_1_mold_achie_rate
DROP TABLE IF EXISTS t_2_1_mold_achie_rate;
CREATE TABLE t_2_1_mold_achie_rate (internal_id  INTEGER(11) NOT NULL,plan  INTEGER(11),achieved  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_2_1_mold_achie_rate (internal_id, plan, achieved) VALUES (2, 200, 110);

-- 表：t_2_2_wp_achie_rate
DROP TABLE IF EXISTS t_2_2_wp_achie_rate;
CREATE TABLE t_2_2_wp_achie_rate (internal_id  INTEGER(11) NOT NULL,name  TEXT(255),plan  INTEGER(11),achieved  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_2_2_wp_achie_rate (internal_id, name, plan, achieved) VALUES (1, '模仁', 100, 200);
INSERT INTO t_2_2_wp_achie_rate (internal_id, name, plan, achieved) VALUES (2, '镶件', 122, 100);
INSERT INTO t_2_2_wp_achie_rate (internal_id, name, plan, achieved) VALUES (3, '辅件', 300, 500);
INSERT INTO t_2_2_wp_achie_rate (internal_id, name, plan, achieved) VALUES (4, '电极', 155, 200);

-- 表：t_2_3_wp_achie_number
DROP TABLE IF EXISTS t_2_3_wp_achie_number;
CREATE TABLE t_2_3_wp_achie_number (internal_id  INTEGER(11) NOT NULL,wp_achie_number  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_2_3_wp_achie_number (internal_id, wp_achie_number) VALUES (1, 1234);

-- 表：t_2_4_process_achie_number
DROP TABLE IF EXISTS t_2_4_process_achie_number;
CREATE TABLE t_2_4_process_achie_number (internal_id  INTEGER(11) NOT NULL,day  INTEGER(2),green  INTEGER(11),blue  INTEGER(11),red  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (1, 1, 20, 3, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (2, 2, 20, 2, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (3, 3, 23, 3, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (4, 4, 32, 4, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (5, 5, 43, 5, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (6, 6, 23, 3, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (7, 7, 44, 0, 5);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (8, 8, 12, 0, 5);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (9, 9, 54, 0, 4);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (10, 10, 42, 0, 3);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (11, 11, 47, 6, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (12, 12, 34, 4, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (13, 13, 25, 3, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (14, 14, 38, 6, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (15, 15, 43, 0, 4);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (16, 16, 56, 0, 3);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (17, 17, 65, 4, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (18, 18, 43, 5, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (19, 19, 34, 0, 5);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (20, 20, 55, 3, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (21, 21, 47, 6, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (22, 22, 34, 4, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (23, 23, 25, 3, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (24, 24, 38, 6, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (25, 25, 43, 0, 4);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (26, 26, 56, 0, 3);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (27, 27, 65, 4, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (28, 28, 43, 5, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (29, 29, 34, 0, 5);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (30, 30, 55, 3, 0);
INSERT INTO t_2_4_process_achie_number (internal_id, day, green, blue, red) VALUES (31, 31, 42, 0, 3);

-- 表：t_3_1_device_runtime
DROP TABLE IF EXISTS t_3_1_device_runtime;
CREATE TABLE t_3_1_device_runtime (internal_id  INTEGER(11) NOT NULL,group_name  TEXT(4) NOT NULL,no_id  INTEGER(11) NOT NULL,name  TEXT(255),text_1  TEXT(255),text_2  TEXT(255),status  INTEGER(1) NOT NULL,PRIMARY KEY (internal_id));

INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (1, 'CNC', 1, 'CNC1', '190411', 'PID11', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (2, 'CNC', 2, 'CNC2', '190412', 'PID12', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (3, 'CNC', 3, 'CNC3', '190413', 'PID13', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (4, 'CNC', 4, 'CNC4', '190414', 'PID14', 2);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (5, 'CNC', 5, 'CNC5', '190415', 'PID15', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (6, 'CNC', 6, 'CNC6', '190416', 'PID16', 2);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (7, 'CNC', 7, 'CNC7', '190417', 'PID17', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (8, 'CNC', 8, NULL, NULL, NULL, 4);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (9, 'EDM', 1, 'EDM1', '190421', 'PID22', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (10, 'EDM', 2, 'EDM2', '190422', 'PID23', 2);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (11, 'EDM', 3, 'EDM3', '190423', 'PID24', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (12, 'EDM', 4, 'EDM4', '190424', 'PID24', 3);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (13, 'EDM', 5, 'EDM5', '190425', 'PID25', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (14, 'EDM', 6, 'EDM6', '190426', 'PID26', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (15, 'EDM', 7, 'EDM7', '190427', 'PID27', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (16, 'EDM', 8, 'EDM8', '190428', 'PID28', 2);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (17, 'WEDM', 1, 'WEDM1', '190431', 'PID28', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (18, 'WEDM', 2, 'WEDM2', '190432', 'PID32', 3);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (19, 'WEDM', 3, 'WEDM3', '190434', 'PID29', 2);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (20, 'WEDM', 4, 'WEDM4', '190435', 'PID30', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (21, 'WEDM', 5, 'WEDM5', '190437', 'PID37', 1);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (22, 'WEDM', 6, 'WEDM6', '190438', 'PID38', 3);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (23, 'WEDM', 7, NULL, NULL, NULL, 4);
INSERT INTO t_3_1_device_runtime (internal_id, group_name, no_id, name, text_1, text_2, status) VALUES (24, 'WEDM', 8, NULL, NULL, NULL, 4);

-- 表：t_3_2_oee
DROP TABLE IF EXISTS t_3_2_oee;
CREATE TABLE t_3_2_oee (internal_id  INTEGER(11) NOT NULL,cnc  INTEGER(3),edm  INTEGER(3),wedm  INTEGER(3),PRIMARY KEY (internal_id));
INSERT INTO t_3_2_oee (internal_id, cnc, edm, wedm) VALUES (1, 110, 90, 90);

-- 表：t_4_1_mold_progress
DROP TABLE IF EXISTS t_4_1_mold_progress;
CREATE TABLE t_4_1_mold_progress (internal_id  INTEGER(11) NOT NULL,mold_no  TEXT(11),tn_no  TEXT(11),type  TEXT(255),status  TEXT(255),product_name  TEXT(255),plan_date  TEXT,green  INTEGER(11),yellow  INTEGER(11),red  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (1, 'IK19001', 'T0', '新模', '加工中', '后盖', '2019-03-29', 60, 20, 20);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (2, 'IK19002', 'T1', '修模', '加工中', '前盖', '2019-04-03', 50, 50, 0);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (3, 'IK29003', 'T2', '修模', '加工中', '外壳', '2019-04-08', 30, 70, 0);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (4, 'IK19004', 'T0', '新模', '加工中', '侧边', '2019-04-18', 90, 5, 5);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (5, 'IK19005', 'T3', '修模', '加工中', '边框', '2019-04-03', 60, 40, 0);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (6, 'IK19006', 'T0', '新模', '加工中', '后盖', '2019-04-26', 70, 25, 5);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (7, 'IK19007', 'T0', '新模', '加工中', '面板', '2019-04-07', 25, 25, 50);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (8, 'IK19008', 'T0', '新模', '加工中', '插件', '2019-03-31', 20, 40, 40);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (9, 'IK19009', 'T1', '修模', '加工中', '面板', '2019-03-12', 10, 60, 30);
INSERT INTO t_4_1_mold_progress (internal_id, mold_no, tn_no, type, status, product_name, plan_date, green, yellow, red) VALUES (10, 'IK19010', 'T2', '修模', '加工中', '后盖', '2019-02-12', 0, 100, 0);

-- 表：t_4_2_mold_status_parcent
DROP TABLE IF EXISTS t_4_2_mold_status_parcent;
CREATE TABLE t_4_2_mold_status_parcent (internal_id  INTEGER(11) NOT NULL,finished  INTEGER(11),processing  INTEGER(11),delay  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_4_2_mold_status_parcent (internal_id, finished, processing, delay) VALUES (1, 60, 25, 15);

-- 表：t_4_3_mold_processing_num
DROP TABLE IF EXISTS t_4_3_mold_processing_num;
CREATE TABLE t_4_3_mold_processing_num (internal_id  INTEGER(11) NOT NULL,mold_processing_number  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_4_3_mold_processing_num (internal_id, mold_processing_number) VALUES (1, 87);

-- 表：t_5_1_work_load
DROP TABLE IF EXISTS t_5_1_work_load;
CREATE TABLE t_5_1_work_load (internal_id  INTEGER(11) NOT NULL,process_name  TEXT(255),work_load_1  TEXT(255),work_load_2  TEXT(255),work_load_3  TEXT(255),work_load_4  TEXT(255),work_load_5  TEXT(255),work_load_6  TEXT(255),work_load_7  TEXT(255),PRIMARY KEY (internal_id));

INSERT INTO t_5_1_work_load (internal_id, process_name, work_load_1, work_load_2, work_load_3, work_load_4, work_load_5, work_load_6, work_load_7) VALUES (1, 'CNC粗', '101H', '81H', '90H', '120H', '30H', '60H', '120H');
INSERT INTO t_5_1_work_load (internal_id, process_name, work_load_1, work_load_2, work_load_3, work_load_4, work_load_5, work_load_6, work_load_7) VALUES (2, 'CNC精', '102H', '102H', '120H', '81H', '45H', '102H', '81H');
INSERT INTO t_5_1_work_load (internal_id, process_name, work_load_1, work_load_2, work_load_3, work_load_4, work_load_5, work_load_6, work_load_7) VALUES (3, 'EDM', '77H', '102H', '90H', '102H', '45H', '90H', '120H');
INSERT INTO t_5_1_work_load (internal_id, process_name, work_load_1, work_load_2, work_load_3, work_load_4, work_load_5, work_load_6, work_load_7) VALUES (4, 'WEDM', '87H', '102H', '120H', '45H', '102H', '102H', '90H');
INSERT INTO t_5_1_work_load (internal_id, process_name, work_load_1, work_load_2, work_load_3, work_load_4, work_load_5, work_load_6, work_load_7) VALUES (5, '抛光', '45H', '102H', '102H', '90H', '81H', '81H', '81H');
INSERT INTO t_5_1_work_load (internal_id, process_name, work_load_1, work_load_2, work_load_3, work_load_4, work_load_5, work_load_6, work_load_7) VALUES (6, '钳工', '89H', '90H', '45H', '120H', '120H', '120H', '102H');
INSERT INTO t_5_1_work_load (internal_id, process_name, work_load_1, work_load_2, work_load_3, work_load_4, work_load_5, work_load_6, work_load_7) VALUES (7, '组装', '77H', '90H', '81H', '102H', '45H', '102H', '81H');

-- 表：t_5_1_work_load_table_head
DROP TABLE IF EXISTS t_5_1_work_load_table_head;
CREATE TABLE t_5_1_work_load_table_head (internal_id  INTEGER(11) NOT NULL,date_1  TEXT,date_2  TEXT,date_3  TEXT,date_4  TEXT,date_5  TEXT,date_6  TEXT,date_7  TEXT,PRIMARY KEY (internal_id));

INSERT INTO t_5_1_work_load_table_head (internal_id, date_1, date_2, date_3, date_4, date_5, date_6, date_7) VALUES (1, '2019-04-30', '2019-05-01', '2019-05-02', '2019-05-03', '2019-05-04', '2019-05-05', '2019-05-06');

-- 表：t_5_2_work_load_today
DROP TABLE IF EXISTS t_5_2_work_load_today;
CREATE TABLE t_5_2_work_load_today (internal_id  INTEGER(11) NOT NULL,group_name  TEXT(255),green  REAL(11,1),red  REAL(11,1),PRIMARY KEY (internal_id));

INSERT INTO t_5_2_work_load_today (internal_id, group_name, green, red) VALUES (1, 'CNC粗', 20, 20);
INSERT INTO t_5_2_work_load_today (internal_id, group_name, green, red) VALUES (2, 'CNC精', 40, 20);
INSERT INTO t_5_2_work_load_today (internal_id, group_name, green, red) VALUES (3, 'EDM', 60, 0);
INSERT INTO t_5_2_work_load_today (internal_id, group_name, green, red) VALUES (4, 'WEDM', 30.2, 2);
INSERT INTO t_5_2_work_load_today (internal_id, group_name, green, red) VALUES (5, '铣床', 40, 0);
INSERT INTO t_5_2_work_load_today (internal_id, group_name, green, red) VALUES (6, '磨床', 30, 50);
INSERT INTO t_5_2_work_load_today (internal_id, group_name, green, red) VALUES (7, 'sd', 67, 68);
INSERT INTO t_5_2_work_load_today (internal_id, group_name, green, red) VALUES (8, 'gg', 88, 99);

-- 表：t_5_3_work_load_percent
DROP TABLE IF EXISTS t_5_3_work_load_percent;
CREATE TABLE t_5_3_work_load_percent (internal_id  INTEGER(11) NOT NULL,group_name  TEXT(255),day_1  INTEGER(3),day_2  INTEGER(3),day_3  INTEGER(3),day_4  INTEGER(3),day_5  INTEGER(3),day_6  INTEGER(3),day_7  INTEGER(3),PRIMARY KEY (internal_id));

INSERT INTO t_5_3_work_load_percent (internal_id, group_name, day_1, day_2, day_3, day_4, day_5, day_6, day_7) VALUES (1, 'CNC粗', 70, 80, 90, 70, 50, 99, 80);
INSERT INTO t_5_3_work_load_percent (internal_id, group_name, day_1, day_2, day_3, day_4, day_5, day_6, day_7) VALUES (2, 'CNC精', 120, 100, 130, 140, 90, 100, 85);
INSERT INTO t_5_3_work_load_percent (internal_id, group_name, day_1, day_2, day_3, day_4, day_5, day_6, day_7) VALUES (3, 'EDM', 120, 100, 120, 80, 90, 40, 50);
INSERT INTO t_5_3_work_load_percent (internal_id, group_name, day_1, day_2, day_3, day_4, day_5, day_6, day_7) VALUES (4, 'WEDM', 100, 120, 120, 100, 100, 80, 70);
INSERT INTO t_5_3_work_load_percent (internal_id, group_name, day_1, day_2, day_3, day_4, day_5, day_6, day_7) VALUES (5, '铣床', 90, 80, 75, 40, 12, 30, 10);
INSERT INTO t_5_3_work_load_percent (internal_id, group_name, day_1, day_2, day_3, day_4, day_5, day_6, day_7) VALUES (6, '磨床', 80, 70, 50, 60, 40, 50, 30);
INSERT INTO t_5_3_work_load_percent (internal_id, group_name, day_1, day_2, day_3, day_4, day_5, day_6, day_7) VALUES (7, 'ff', 67, 77, 88, 12, 33, 44, 55);

-- 表：t_6_1_wp_qual_rate
DROP TABLE IF EXISTS t_6_1_wp_qual_rate;
CREATE TABLE t_6_1_wp_qual_rate (internal_id  INTEGER(11) NOT NULL,date_1  INTEGER(3),date_2  INTEGER(3),date_3  INTEGER(3),date_4  INTEGER(3),date_5  INTEGER(3),date_6  INTEGER(3),date_7  INTEGER(3),date_8  INTEGER(3),date_9  INTEGER(3),date_10  INTEGER(3),date_11  INTEGER(3),date_12  INTEGER(3),date_13  INTEGER(3),date_14  INTEGER(3),date_15  INTEGER(3),PRIMARY KEY (internal_id));

INSERT INTO t_6_1_wp_qual_rate (internal_id, date_1, date_2, date_3, date_4, date_5, date_6, date_7, date_8, date_9, date_10, date_11, date_12, date_13, date_14, date_15) VALUES (1, 100, 99, 89, 95, 95, 92, 98, 100, 96, 97, 98, 99, 90, 85, 84);

-- 表：t_6_2_ele_qual_rate
DROP TABLE IF EXISTS t_6_2_ele_qual_rate;
CREATE TABLE t_6_2_ele_qual_rate (internal_id  INTEGER(11) NOT NULL,date_1  INTEGER(3),date_2  INTEGER(3),date_3  INTEGER(3),date_4  INTEGER(3),date_5  INTEGER(3),date_6  INTEGER(3),date_7  INTEGER(3),date_8  INTEGER(3),date_9  INTEGER(3),date_10  INTEGER(3),date_11  INTEGER(3),date_12  INTEGER(3),date_13  INTEGER(3),date_14  INTEGER(3),date_15  INTEGER(3),PRIMARY KEY (internal_id));

INSERT INTO t_6_2_ele_qual_rate (internal_id, date_1, date_2, date_3, date_4, date_5, date_6, date_7, date_8, date_9, date_10, date_11, date_12, date_13, date_14, date_15) VALUES (1, 100, 99, 89, 95, 95, 92, 98, 100, 96, 97, 98, 99, 90, 85, 84);

-- 表：t_6_3_qual_rate_today
DROP TABLE IF EXISTS t_6_3_qual_rate_today;
CREATE TABLE t_6_3_qual_rate_today (internal_id  INTEGER(11) NOT NULL,qual_rate  INTEGER(3),PRIMARY KEY (internal_id));

INSERT INTO t_6_3_qual_rate_today (internal_id, qual_rate) VALUES (1, 90);

-- 表：t_6_4_mold_qual_rate
DROP TABLE IF EXISTS t_6_4_mold_qual_rate;
CREATE TABLE t_6_4_mold_qual_rate (internal_id  INTEGER(11) NOT NULL,mold_name  TEXT(255),qual_rate  INTEGER(3),PRIMARY KEY (internal_id));

INSERT INTO t_6_4_mold_qual_rate (internal_id, mold_name, qual_rate) VALUES (1, 'IK19001', 95);
INSERT INTO t_6_4_mold_qual_rate (internal_id, mold_name, qual_rate) VALUES (2, 'IK19002', 88);
INSERT INTO t_6_4_mold_qual_rate (internal_id, mold_name, qual_rate) VALUES (3, 'IK19003', 94);
INSERT INTO t_6_4_mold_qual_rate (internal_id, mold_name, qual_rate) VALUES (4, 'IK19004', 75);
INSERT INTO t_6_4_mold_qual_rate (internal_id, mold_name, qual_rate) VALUES (5, 'IK19005', 94);
INSERT INTO t_6_4_mold_qual_rate (internal_id, mold_name, qual_rate) VALUES (6, 'IK19006', 89);

-- 表：t_7_1_qual_percent
DROP TABLE IF EXISTS t_7_1_qual_percent;
CREATE TABLE t_7_1_qual_percent (internal_id  INTEGER(11) NOT NULL,green  INTEGER(3),blue  INTEGER(3),yellow  INTEGER(3),red  INTEGER(3),PRIMARY KEY (internal_id));

INSERT INTO t_7_1_qual_percent (internal_id, green, blue, yellow, red) VALUES (1, 90, 5, 3, 1);

-- 表：t_7_2_group_qual_rate
DROP TABLE IF EXISTS t_7_2_group_qual_rate;
CREATE TABLE t_7_2_group_qual_rate (internal_id  INTEGER(11) NOT NULL,group_name  TEXT(255),qual_rate  INTEGER(3),PRIMARY KEY (internal_id));

INSERT INTO t_7_2_group_qual_rate (internal_id, group_name, qual_rate) VALUES (1, 'CNC', 90);
INSERT INTO t_7_2_group_qual_rate (internal_id, group_name, qual_rate) VALUES (2, 'EDM', 85);
INSERT INTO t_7_2_group_qual_rate (internal_id, group_name, qual_rate) VALUES (3, 'WEDM', 92);
INSERT INTO t_7_2_group_qual_rate (internal_id, group_name, qual_rate) VALUES (4, '磨床', 94);
INSERT INTO t_7_2_group_qual_rate (internal_id, group_name, qual_rate) VALUES (5, '铣床', 93);
INSERT INTO t_7_2_group_qual_rate (internal_id, group_name, qual_rate) VALUES (6, '外协', 92);

-- 表：t_7_3_qual_rate_daily
DROP TABLE IF EXISTS t_7_3_qual_rate_daily;
CREATE TABLE t_7_3_qual_rate_daily (internal_id  INTEGER(11) NOT NULL,group_name  TEXT(255),day_1  INTEGER(3),day_2  INTEGER(3),day_3  INTEGER(3),day_4  INTEGER(3),day_5  INTEGER(3),day_6  INTEGER(3),day_7  INTEGER(3),day_8  INTEGER(3),day_9  INTEGER(3),day_10  INTEGER(3),day_11  INTEGER(3),day_12  INTEGER(3),day_13  INTEGER(3),day_14  INTEGER(3),day_15  INTEGER(3),day_16  INTEGER(3),day_17  INTEGER(3),day_18  INTEGER(3),day_19  INTEGER(3),day_20  INTEGER(3),day_21  INTEGER(3),day_22  INTEGER(3),day_23  INTEGER(3),day_24  INTEGER(3),day_25  INTEGER(3),day_26  INTEGER(3),day_27  INTEGER(3),day_28  INTEGER(3),day_29  INTEGER(3),day_30  INTEGER(3),day_31  INTEGER(3),PRIMARY KEY (internal_id));

INSERT INTO t_7_3_qual_rate_daily (internal_id, group_name, day_1, day_2, day_3, day_4, day_5, day_6, day_7, day_8, day_9, day_10, day_11, day_12, day_13, day_14, day_15, day_16, day_17, day_18, day_19, day_20, day_21, day_22, day_23, day_24, day_25, day_26, day_27, day_28, day_29, day_30, day_31) VALUES (1, 'all', 90, 90, 97, 91, 92, 88, 89, 90, 78, 87, 86, 90, 80, 97, 87, 87, 88, 89, 90, 90, 89, 86, 90, 80, 97, 87, 87, 89, 89, 89, 90);

-- 表：t_8_1_key_invt
DROP TABLE IF EXISTS t_8_1_key_invt;
CREATE TABLE t_8_1_key_invt (internal_id  INTEGER(11) NOT NULL,name  TEXT(255),upper_bound  INTEGER(11),current  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_8_1_key_invt (internal_id, name, upper_bound, current) VALUES (1, '刀具A1', 200, 110);
INSERT INTO t_8_1_key_invt (internal_id, name, upper_bound, current) VALUES (2, '顶针B', 100, 70);
INSERT INTO t_8_1_key_invt (internal_id, name, upper_bound, current) VALUES (3, '线割丝C', 100, 300);
INSERT INTO t_8_1_key_invt (internal_id, name, upper_bound, current) VALUES (4, '树脂D', 100, 10);

-- 表：t_8_2_invt_table
DROP TABLE IF EXISTS t_8_2_invt_table;
CREATE TABLE t_8_2_invt_table (internal_id  INTEGER(11) NOT NULL,invt_no  TEXT(255),name  TEXT(255),spec  TEXT(255),mat  TEXT(255),size  TEXT(255),target  INTEGER(11),current  INTEGER(11),PRIMARY KEY (internal_id));

INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (1, 'SSDDS1', '品名1', '规格1', '材料1', '34*54*20', 200, 90);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (2, 'SSDDS2', '品名2', '规格2', '材料2', '34*54*20', 100, 120);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (3, 'SSDDS3', '品名3', '规格3', '材料3', '34*54*20', 100, 67);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (4, 'SSDDS4', '品名4', '规格4', '材料4', '34*54*20', 100, 88);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (5, 'SSDDS5', '品名5', '规格5', '材料5', '34*54*20', 100, 45);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (6, 'SSDDS6', '品名6', '规格6', '材料6', '34*54*20', 100, 87);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (7, 'SSDDS7', '品名7', '规格7', '材料7', '34*54*20', 100, 9);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (8, 'SSDDS8', '品名8', '规格8', '材料8', '34*54*20', 100, 44);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (9, 'SSDDS9', '品名9', '规格9', '材料9', '34*54*20', 100, 100);
INSERT INTO t_8_2_invt_table (internal_id, invt_no, name, spec, mat, size, target, current) VALUES (10, 'SSDDS0', '品名0', '规格0', '材料0', '34*54*20', 100, 54);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
