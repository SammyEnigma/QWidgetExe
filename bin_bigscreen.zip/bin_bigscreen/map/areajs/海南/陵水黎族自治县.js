(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    }
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    if (!echarts.registerMap) {
        log('ECharts Map is not loaded');
        return;
    }
    echarts.registerMap('陵水黎族自治县', {"type":"FeatureCollection","features":[{"type":"Feature","id":"469028","properties":{"name":"陵水黎族自治县","cp":[110.037218,18.505006],"childNum":2},"geometry":{"type":"MultiPolygon","coordinates":[["@@@G@EACAA@E@G@EFM@C@AACAEACAEBC@GBGDM@GDIFSBAHEDA@A@CBK@ABAFIHGFCDAB@B@FBBBD@L@J@H@DAB@BA@CBADEDADAHGJIDAH@F@DBB@B@BABCFIHK@AD@B@BABAFEDCBAB@DBFBBDFFBBB@HBBBBB@BBBBBB@B@D@D@FAB@B@@CBC@ABADAHAD@F@B@D@B@DAJ@D@D@BAaaW}aQe_IKQaM}IK{GOKQSKqOoQOA_BSFUF_LeF[BW@WE³W[[¬A@EAEHLDBBAB@FAJAF@DCD@BADAD@H@FBDB@HBL@JDB@BBBDBD@H@F@B@@@@@@@BBB@DBB@@@BDD@@BBBF@FCJAFADEDCFEHADC@I@G@IFCBEFEN@BBFBDBD@DB@BBBB@@@@JAF@B@DDDD@@BBB@HADFDBB@B@BE@C@ABE@A@@BAF@FBBBA@@DBB@BBBBA@ABALCJDBBBDJNDJAL@BABABBN@@JFFB@@D@FHDB@J@@@@@BDF@B@BCHEB@B@D@B@BA@G@GCCAA@A@AB@BA@@@E@C@EDAN@BAD@@CDA@E@A@A@AACB@@CB@@@B@DA@CBCJA@BBBH@F@HAH@FBH@BBH@BBD@@AD@D@DB@@@HBBBBBBDBBB@BBDAB@B@BBB@BAB@DAB@B@BB@BBFAF@FAFADADADCFAB@D@BBB@BB@BBB@DAF@@@B@@BBH@BDBDJBD@D@@CFCDEFABGPABEBAB@@AB@F@D@BBD@@@@A@E@K@G@CBA@ABAFAH@J@FBD@@@@A@A@GCIEMCGAC@A@EDEDABAD@D@F@BJLB@@BABIDED@B@B@BBDFZ@B@BA@ODMBABAB@@BF@DBFAD@DAD@HBF@DBDBBDBFDBHBDDDLLBB@@BEBCAA@ABADA@CBAFE@A@@D@F@B@B@B@FGJEFEDAFEBGBC@CBCBABABA@A@CAC@A@C@ABC@KFM@ABAB@BBB@B@B@@@HKHIFEBAB@H@B@DBBBB@DBD@F@JADAD@B@BBBBBBB@FHBD@@BBB@BBB@BBBD@DBD@@@BB@B@D@BAB@B@@BDDFJDBBBDAB@BABABGDGFIDABAB@BB@B@@BD@@@BDBDBBBBBHFHHFJBB@BB@B@B@B@B@BB@@BBBB@@D@B@B@D@BBBBBDBBBBDBDBF@JBB@D@D@DBB@B@@@D@D@B@B@@@DABCHEBABAB@DBB@B@@@DABCDE@E@@DAB@DCBADE@A@GBADCFAFEDEDCDADAF@F@"],["@@B@BBB@@@@A@@@@@@AA@@@@@@@AC@@@A@@D@@@@B@"]],"encodeOffsets":[[[112656,19183]],[[112788,18878]]]}}],"UTF8Encoding":true});
}));